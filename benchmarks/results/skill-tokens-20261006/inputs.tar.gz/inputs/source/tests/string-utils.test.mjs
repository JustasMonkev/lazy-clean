import test from 'node:test';
import assert from 'node:assert/strict';
import { trimString, trimStringWithEllipsis, escapeTemplateString, truncateDataUrl } from '../packages/isomorphic/stringUtils.ts';
test('ASCII trimming retains cap', () => assert.equal(trimString('abcdef', 4), 'abcd'));
test('unchanged input is preserved', () => assert.equal(trimString('abc', 3), 'abc'));
test('ellipsis reserves a character', () => assert.equal(trimStringWithEllipsis('abcdef', 4), 'abc…'));
test('template syntax is escaped', () => assert.equal(escapeTemplateString('a'+String.fromCharCode(96)+'b'), 'a\\'+String.fromCharCode(96)+'b'));
test('data URL prefix is retained', () => assert.equal(truncateDataUrl('data:text/plain,hello'), 'data:text/plain,…'));
