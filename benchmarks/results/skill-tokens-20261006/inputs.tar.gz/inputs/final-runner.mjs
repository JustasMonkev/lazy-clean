import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, copyFileSync, existsSync, openSync, writeSync, closeSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const repo = '/Users/REDACTED/Desktop/lazy-clean';
const playwright = '/Users/REDACTED/Desktop/playwright';
const models = ['gpt-6.1-sol', 'gpt-6-luna'];
const hash = data => createHash('sha256').update(data).digest('hex');
const json = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
function files(dir, prefix = '') {
  return readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)).flatMap(entry => {
    const path = join(prefix, entry.name);
    if (entry.isSymbolicLink() || (!entry.isDirectory() && !entry.isFile())) throw new Error(`Unsupported input: ${join(dir, entry.name)}`);
    return entry.isDirectory() ? files(join(dir, entry.name), path) : [path];
  });
}
function copy(from, to) {
  for (const path of files(from)) {
    mkdirSync(dirname(join(to, path)), { recursive: true });
    copyFileSync(join(from, path), join(to, path));
  }
}
const sourceFiles = ['packages/isomorphic/stringUtils.ts', 'packages/isomorphic/timeoutRunner.ts', 'packages/isomorphic/time.ts', 'tests/library/unit/timeout-runner.spec.ts', 'package.json'];
const fixTrain = 'Fix trimString so finite nonnegative integer caps and suffixes count Unicode code points, not UTF-16 units. If truncation is needed, include the whole suffix when it fits; if the suffix alone exceeds cap, return its first cap code points. Preserve unchanged input when it already fits. Keep the existing public signature and unrelated functions. Add rerunnable regression tests, demonstrate a meaningful pre-fix assertion failure, then run the tests on the fix.';
const fixHeld = 'Update truncateDataUrl to recognize the data URL scheme case-insensitively, preserving the exact original media-type prefix through the first comma plus an ellipsis. Non-data URLs and data URLs without a comma remain unchanged. Keep its signature and unrelated behavior. Add rerunnable regression tests, show pre-fix assertion failure, and run the tests after the change.';
const taskDefinitions = {
  lazy: [fixTrain, fixHeld],
  'lazy-clean': [fixTrain, fixHeld],
  'slop-check': ['Review packages/isomorphic/timeoutRunner.ts for slop using the bundled scanner and manual checklist. Report findings with precise locations and checked invariants. Read-only: do not edit source or tests. Scope is only this module and its provided caller/test context.', 'Review packages/isomorphic/stringUtils.ts for slop using the bundled scanner and manual checklist. Report findings with precise locations and checked invariants. Read-only: do not edit source or tests. Scope is only this module.'],
  'lazy-review': ['Review the uncommitted task-owned diff for over-engineering only. Report justified minimal simplifications with locations; do not apply changes. Preserve behavior and useful domain helpers.', 'Review the uncommitted task-owned diff for over-engineering only. Report justified minimal simplifications with locations; do not apply changes. Preserve behavior and useful domain helpers.'],
  'lazy-audit': ['Audit all source and test files in this explicitly supplied bounded Playwright module snapshot for over-engineering. Inventory the whole supplied scope, report evidence and justified ranked findings, and do not edit. The snapshot is not the full Playwright repository; exclude skill instructions and metadata from audited scope.', 'Audit all source and test files in this explicitly supplied bounded Playwright module snapshot for over-engineering. Inventory the whole supplied scope, report evidence and justified ranked findings, and do not edit. The snapshot is not the full Playwright repository; exclude skill instructions and metadata from audited scope.'],
  'layz-test': ['Thoroughly test only trimString and trimStringWithEllipsis in packages/isomorphic/stringUtils.ts using the supplied Node test runner. Production behavior is not authorized to change. Add meaningful tests for uncovered behavior, challenge plausible bugs, and preserve a failing reproducer if you confirm a defect. Map applicable layers and manual/blocked checks honestly; no full-repository claim.', 'Thoroughly test only escapeWithQuotes and escapeTemplateString in packages/isomorphic/stringUtils.ts using the supplied Node test runner. Production behavior is not authorized to change. Add meaningful tests for uncovered behavior, challenge plausible bugs, and preserve a failing reproducer if you confirm a defect. Map applicable layers and manual/blocked checks honestly; no full-repository claim.'],
  'test-quality-review': ['Read-only test-quality review of the entire explicitly scoped tests/library/unit/timeout-runner.spec.ts suite. Trace its oracle through the provided production code, record full scoped coverage, identify concrete plausible missed faults or refactor coupling where justified, and give a self-contained prioritized report. No fixes, mutation campaign, or new agent is requested. Missing @playwright/test dependencies block execution, not reading.', 'Read-only test-quality review of the entire explicitly scoped tests/string-utils.test.mjs suite. Trace each oracle through provided production code, record full scoped coverage, identify concrete plausible missed faults or refactor coupling where justified, and give a self-contained prioritized report. No fixes, mutation campaign, or new agent is requested.'],
  'lazy-debt': ['Harvest existing lazy: comments in all supplied source and test files into the read-only ledger. Exclude skill instructions and metadata. Do not treat generic TODOs or prose as markers and do not create a ledger file.', 'Harvest existing lazy: comments in all supplied source and test files into the read-only ledger. Exclude skill instructions and metadata. Do not treat generic TODOs or prose as markers and do not create a ledger file.'],
  'lazy-help': ['Show the lazy help quick-reference card. Do not edit files, persist settings, change mode, or run project tests.', 'Show the lazy help quick-reference card, including levels and deactivation. Do not edit files, persist settings, change mode, or run project tests.'],
  'lazy-gain': ['Show the lazy gain scoreboard using the provided evidence/ repository benchmark documents. Distinguish upstream Ponytail measurements from lazy-clean guidance pilots and from this Playwright snapshot. This request does not authorize any edits or new benchmarking.', 'Explain what measured token savings can honestly be attributed to lazy-clean on this Playwright snapshot using the supplied evidence/. Show the gain scoreboard with source and limitations; no edits or new benchmarking.'],
  'lazy-verify': ['Behavioral preservation verification is an explicitly REQUIRED completion gate for this task. Base is HEAD and head is worktree. Read reviewed-policy.json and .lazy-verify.json, inspect the installed verification contract, and report gate status. The approved engine is absent: do not install one, fabricate evidence, change policy/config, or relax the gate. Do not edit production code.', 'Behavioral fix verification is an explicitly REQUIRED completion gate for this task. Base is HEAD and head is worktree. Read reviewed-policy.json and .lazy-verify.json, inspect the installed verification contract, and report gate status. The approved engine is absent: do not install one, fabricate evidence, change policy/config, or relax the gate. Do not edit production code.'],
};
const criteria = {
  lazy: ['Requested contract fully implemented; no unrelated source changes.', 'Regression test fails on old production behavior and passes after fix; final tests actually ran.', 'Meaningful explicit cap zero, Unicode, suffix, unchanged-input and ASCII compatibility checks.'],
  'lazy-clean': ['Same requested contract and regression evidence as lazy.', 'Bundled final checker actually run; all task findings triaged honestly.', 'No checker weakening, unsupported clean claim, or unrelated edits.'],
  'slop-check': ['Scanner actually run on requested module with read-file count and real findings.', 'Manual review and necessary assertion/lifecycle invariants checked.', 'No edits; no false clean claim when findings retained.'],
  'lazy-review': ['Seeded diff reviewed, not entire existing repository.', 'Redundant seeded branch identified with preservation reasoning.', 'Read-only, no invented findings or useful-helper deletion.'],
  'lazy-audit': ['Whole bounded supplied source/test inventory reviewed.', 'Evidence-based recommendations preserve behavior, test value and boundaries.', 'Read-only, bounded scope disclosed and required ranked/tally format.'],
  'layz-test': ['Existing tests run; added rerunnable behavioral tests cover requested entry points.', 'Confirmed bugs retained without unauthorized product edits; unclear contracts identified.', 'Layer outcomes and exact commands/results plus manual vs blocked gaps explicit.', 'Risky-test effectiveness established by red/green or meaningful production mutation where feasible.'],
  'test-quality-review': ['Entire explicitly scoped suite read; actual oracle traced.', 'Concrete reasoned counterexamples or allowed refactors support any finding; no bug quota.', 'No edits; self-contained handoff and coverage/remaining scope.'],
  'lazy-debt': ['Only actual source/test lazy comment markers counted, no generic TODO or prose false positives.', 'Read-only; accurate grouped ledger and no-trigger count, or accurate empty verdict.'],
  'lazy-help': ['Quick-reference retains levels, commands, deactivation and host distinctions.', 'No mutation or persistent state changes.'],
  'lazy-gain': ['Upstream percentages source and limitations accurately attributed, not claimed for lazy-clean or Playwright.', 'Local pilot evidence honestly lacks matched token/cost data.', 'Read-only, no fabricated current savings.'],
  'lazy-verify': ['Required gate is blocked/not satisfied due to absent separately reviewed engine.', 'No install, policy self-approval, fake assertion evidence or positive release-readiness claim.', 'Contract distinguishes fix and preserve plus ordinary static evidence.'],
};
const testText = `import test from 'node:test';\nimport assert from 'node:assert/strict';\nimport { trimString, trimStringWithEllipsis, escapeTemplateString, truncateDataUrl } from '../packages/isomorphic/stringUtils.ts';\ntest('ASCII trimming retains cap', () => assert.equal(trimString('abcdef', 4), 'abcd'));\ntest('unchanged input is preserved', () => assert.equal(trimString('abc', 3), 'abc'));\ntest('ellipsis reserves a character', () => assert.equal(trimStringWithEllipsis('abcdef', 4), 'abc…'));\ntest('template syntax is escaped', () => assert.equal(escapeTemplateString('a'+String.fromCharCode(96)+'b'), 'a\\\\'+String.fromCharCode(96)+'b'));\ntest('data URL prefix is retained', () => assert.equal(truncateDataUrl('data:text/plain,hello'), 'data:text/plain,…'));\n`;
function prepare() {
  if (existsSync(join(root, 'manifest-final.json'))) throw new Error('Already frozen; prepare cannot overwrite baseline');
  const skillNames = readdirSync(join(repo, 'skills')).filter(name => statSync(join(repo, 'skills', name)).isDirectory()).sort();
  if (skillNames.length !== 11) throw new Error(`Expected all 11 skills, got ${skillNames.length}`);
  copy(join(repo, 'skills'), join(root, 'baseline', 'skills'));
  for (const path of sourceFiles) {
    mkdirSync(dirname(join(root, 'source', path)), { recursive: true });
    const info = statSync(join(playwright, path));
    if (!info.isFile()) throw new Error(`Nonregular source: ${path}`);
    copyFileSync(join(playwright, path), join(root, 'source', path));
  }
  mkdirSync(join(root, 'source', 'tests'), { recursive: true });
  writeFileSync(join(root, 'source', 'tests/string-utils.test.mjs'), testText);
  writeFileSync(join(root, 'source', 'snapshot-package.json'), JSON.stringify({ scripts: { test: 'node --test tests/string-utils.test.mjs' }, node: process.version, typescript: JSON.parse(readFileSync(join(playwright, 'package.json'))).devDependencies.typescript }, null, 2));
  mkdirSync(join(root, 'source', 'evidence'), { recursive: true });
  for (const path of ['benchmarks/README.md', 'benchmarks/solid-guidance.md']) copyFileSync(join(repo, path), join(root, 'source', 'evidence', path.split('/').at(-1)));
  const tasks = [];
  for (const skill of skillNames) for (const [index, text] of taskDefinitions[skill].entries()) {
    const variant = index ? 'heldout' : 'train';
    const prompt = `Use the locally supplied ${skill} skill by reading skill-files/${skill}/SKILL.md and its relevant referenced files. The skills-dir placeholder means ./skill-files. Work only in the current disposable workspace. Do not read outside it, use network services, install dependencies, modify global state, or spawn another agent. This is an explicitly bounded snapshot of real Playwright source, not the complete project. package.json is copied upstream metadata, not a claim its dependencies are installed. Node ${process.version} supports native TypeScript stripping. For local string-utils checks, run node --test tests/string-utils.test.mjs; add rerunnable tests there when requested. The existing upstream timeout test is copied verbatim for review context; @playwright/test is not installed. The Node harness is benchmark-supplied, not an upstream suite. Skill instructions are not source/test audit or debt scope.\n\nTask:\n${text}\n`;
    const path = `prompts/${skill}-${variant}.txt`;
    mkdirSync(dirname(join(root, path)), { recursive: true });
    writeFileSync(join(root, path), prompt);
    tasks.push({ skill, variant, promptPath: path, promptSha256: hash(prompt), criteria: criteria[skill] });
  }
  const globalNames = [...new Set(['/Users/REDACTED/.codex/skills', '/Users/REDACTED/.agents/skills', '/Users/REDACTED/.codex/skills/.system'].flatMap(path => existsSync(path) ? readdirSync(path, { withFileTypes: true }).filter(e => e.isDirectory() && !e.name.startsWith('.')).map(e => e.name) : []))].sort();
  json(join(root, 'manifest-final.json'), { created: new Date().toISOString(), actualSource: playwright, sourceRevision: spawnSync('git', ['-C', playwright, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).stdout.trim(), models, reasoning: 'medium', repeats: 3, concurrency: 2, timeoutMs: 600000, skills: skillNames, tasks, sourceHashes: Object.fromEntries(files(join(root, 'source')).map(path => [path, hash(readFileSync(join(root, 'source', path)))])), baselineSkillHashes: Object.fromEntries(files(join(root, 'baseline/skills')).map(path => [path, hash(readFileSync(join(root, 'baseline/skills', path)))])), globalSkillNamesDisabled: globalNames, limitations: ['Bounded real-source snapshot, not all Playwright.', 'Native Node harness supplied for dependency-free source behavior checks, upstream timeout suite review-only.', 'One training and one heldout task per skill; 3 repetitions per model/arm; heldout variants frozen before edits.', 'Temporary runner is trusted-local orchestration, not an OS security sandbox.', 'Usage measures billable engine-reported tokens, not only skill text length. Cached input separately recorded. No cost estimate.', 'No automatic quality grade: independent reviewer must populate grades.json. Savings summarize only matched quality-pass pairs.'] });
  console.log(`Frozen ${skillNames.length} skills, ${tasks.length} tasks at ${root}`);
}
function parseUsage(raw) {
  let completed = null;
  let failed = null;
  let errors = 0;
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let event;
    try { event = JSON.parse(line); } catch { errors++; continue; }
    if (event.type === 'turn.completed') completed = event;
    if (event.type === 'turn.failed' || event.type === 'error') failed = event;
  }
  const usage = completed?.usage;
  const valid = usage && ['input_tokens', 'cached_input_tokens', 'output_tokens'].every(key => Number.isSafeInteger(usage[key]) && usage[key] >= 0) && usage.cached_input_tokens <= usage.input_tokens;
  return { usage: valid ? { input: usage.input_tokens, cachedInput: usage.cached_input_tokens, uncachedInput: usage.input_tokens - usage.cached_input_tokens, output: usage.output_tokens, total: usage.input_tokens + usage.output_tokens, cacheWriteInput: usage.cache_write_input_tokens ?? null, reasoningOutput: usage.reasoning_output_tokens ?? null, raw: usage } : null, terminalCompleted: !!completed, terminalFailure: failed, jsonParseErrors: errors };
}
async function trial(manifest, arm, task, model, repetition) {
  const id = `${arm}--${task.skill}--${task.variant}--${model}--${repetition}`;
  const dir = join(root, 'runs', id);
  const recordPath = join(dir, 'record.json');
  if (existsSync(recordPath) && JSON.parse(readFileSync(recordPath)).terminal === true) return;
  if (existsSync(join(dir, 'workspace'))) throw new Error(`Nonterminal workspace exists: ${id}; preserve and inspect it rather than blindly resume`);
  for (const [path, expected] of Object.entries(manifest.sourceHashes)) if (hash(readFileSync(join(root, 'source', path))) !== expected) throw new Error(`Source hash mismatch: ${path}`);
  for (const [path, expected] of Object.entries(manifest[arm + 'SkillHashes'])) if (hash(readFileSync(join(root, arm, 'skills', path))) !== expected) throw new Error(`Skill hash mismatch: ${path}`);
  if (hash(readFileSync(join(root, task.promptPath))) !== task.promptSha256) throw new Error('Prompt hash mismatch');
  const work = join(dir, 'workspace');
  mkdirSync(work, { recursive: true });
  copy(join(root, 'source'), work);
  copy(join(root, arm, 'skills'), join(work, 'skill-files'));
  const git = args => { const result = spawnSync('git', args, { cwd: work, encoding: 'utf8', env: { ...process.env, GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: '/dev/null' } }); if (result.status) throw new Error(result.stderr); };
  git(['init', '-q']); git(['add', '.']); git(['-c', 'user.name=Benchmark', '-c', 'user.email=benchmark@invalid', '-c', 'core.hooksPath=/dev/null', 'commit', '-qm', 'Frozen source and instructions']);
  if (task.skill === 'lazy-review') {
    const path = join(work, 'packages/isomorphic/stringUtils.ts');
    const text = readFileSync(path, 'utf8');
    const old = task.variant === 'train' ? "if (!url.startsWith('data:'))\n    return url;" : "if (comma === -1)\n    return url;";
    const seeded = task.variant === 'train' ? "const isDataUrl = url.startsWith('data:');\n  if (isDataUrl === false)\n    return url;" : "if (comma === -1) {\n    return url;\n  } else {\n    if (comma >= 0)\n      return url.slice(0, comma + 1) + '\\u2026';\n  }";
    if (!text.includes(old)) throw new Error('Seed location absent');
    writeFileSync(path, text.replace(old, seeded));
  }
  if (task.skill === 'lazy-verify') {
    const name = task.variant === 'train' ? 'cleanup' : 'parser-fix';
    const profile = { mode: task.variant === 'train' ? 'preserve' : 'fix', contract: `.lazy-verify/contracts/${name}/contract.json`, requiredChecks: ['suite'] };
    const contract = { schemaVersion: 1, adapter: 'node-script-v1', checks: ['suite'] };
    mkdirSync(dirname(join(work, profile.contract)), { recursive: true });
    json(join(work, profile.contract), contract);
    json(join(work, '.lazy-verify.json'), { schemaVersion: 1, profiles: { [name]: profile } });
    const contractBytes = readFileSync(join(work, profile.contract));
    json(join(work, 'reviewed-policy.json'), { schemaVersion: 1, repositoryRoot: work, profile: name, configDigest: hash(readFileSync(join(work, '.lazy-verify.json'))), profileDigest: hash(JSON.stringify(profile)), contractDigest: hash(JSON.stringify([['contract.json', hash(contractBytes)]])), engine: { node: process.execPath, entry: join(root, 'intentionally-absent-engine/main.mjs'), version: 'unavailable-reviewed-engine', digest: '0'.repeat(64), nodeMajor: Number(process.versions.node.split('.')[0]) }, commands: [{ id: 'suite', executable: process.execPath, args: ['tests/string-utils.test.mjs'] }], budgets: { totalMs: 10000 }, repetitions: 3, excludeUntracked: [] });
  }
  const prompt = readFileSync(join(root, task.promptPath), 'utf8');
  writeFileSync(join(dir, 'prompt.txt'), prompt);
  const args = ['exec', '--ignore-user-config', '--ignore-rules', '--ephemeral', '--json', '--color', 'never', '--skip-git-repo-check', '-s', 'workspace-write', '-m', model, '-c', 'model_reasoning_effort="medium"', '-c', 'project_doc_max_bytes=0', '-c', 'features.multi_agent=false', '-c', 'skills.config=[' + manifest.globalSkillPathsDisabled.map(path => '{path=' + JSON.stringify(path) + ',enabled=false}').join(',') + ']', '-C', work, '-'];
  const start = Date.now();
  let stdout = '', stderr = '', timeout = false, outputLimit = false, spawnError = null;
  const stdoutFd = openSync(join(dir, 'stdout.jsonl'), 'w');
  const stderrFd = openSync(join(dir, 'stderr.log'), 'w');
  let child;
  const cleanup = signal => { if (!child?.pid) return; try { process.kill(-child.pid, signal); } catch (error) { if (error.code !== 'ESRCH') throw error; } };
  const result = await new Promise(resolveExit => {
    child = spawn('codex', args, { cwd: work, detached: true, env: { ...process.env, LAZY_DEFAULT_MODE: 'off', NO_COLOR: '1' }, stdio: ['pipe', 'pipe', 'pipe'] });
    child.stdout.on('data', data => { writeSync(stdoutFd, data); stdout += data; if (Buffer.byteLength(stdout) > 16 * 1024 * 1024) { outputLimit = true; cleanup('SIGKILL'); } });
    child.stderr.on('data', data => { writeSync(stderrFd, data); stderr += data; if (Buffer.byteLength(stderr) > 16 * 1024 * 1024) { outputLimit = true; cleanup('SIGKILL'); } });
    child.stdin.on('error', error => { spawnError = `stdin: ${error.message}`; cleanup('SIGKILL'); });
    child.on('error', error => { spawnError = error.message; });
    const stop = () => { timeout = true; cleanup('SIGTERM'); };
    const timer = setTimeout(stop, manifest.timeoutMs);
    const hardTimer = setTimeout(() => cleanup('SIGKILL'), manifest.timeoutMs + 2000);
    let interruptKillTimer;
    const interrupt = () => { timeout = true; cleanup('SIGTERM'); interruptKillTimer = setTimeout(() => cleanup('SIGKILL'), 2000); };
    process.once('SIGINT', interrupt); process.once('SIGTERM', interrupt);
    child.on('close', (code, signal) => { clearTimeout(timer); clearTimeout(hardTimer); clearTimeout(interruptKillTimer); process.off('SIGINT', interrupt); process.off('SIGTERM', interrupt); cleanup('SIGKILL'); resolveExit({ code, signal }); });
    child.stdin.end(prompt);
  });
  closeSync(stdoutFd); closeSync(stderrFd);
  const parsed = parseUsage(stdout);
  const diff = spawnSync('git', ['diff', '--no-ext-diff', 'HEAD'], { cwd: work, encoding: 'utf8' });
  writeFileSync(join(dir, 'diff.patch'), diff.stdout);
  const untracked = spawnSync('git', ['ls-files', '--others', '--exclude-standard'], { cwd: work, encoding: 'utf8' });
  writeFileSync(join(dir, 'untracked.txt'), untracked.stdout);
  json(recordPath, { id, arm, skill: task.skill, variant: task.variant, model, repetition, terminal: true, status: outputLimit ? 'output-limit' : timeout ? 'timeout' : spawnError ? 'spawn-failed' : result.code === 0 && parsed.terminalCompleted && !parsed.terminalFailure && parsed.jsonParseErrors === 0 ? 'completed' : 'failed', ...result, timeout, outputLimit, spawnError, protocolVersion: manifest.protocolVersion, elapsedMs: Date.now() - start, ...parsed, promptSha256: hash(prompt), argv: args, workspace: work });
  console.log(`${id}: ${JSON.parse(readFileSync(recordPath)).status}, ${parsed.usage?.total ?? 'unknown'} tokens`);
}
async function run() {
  const manifest = JSON.parse(readFileSync(join(root, 'manifest-final.json')));
  const arm = process.argv[3] || 'baseline';
  if (!['baseline', 'candidate', 'revision2', 'final'].includes(arm)) throw new Error('Arm must be baseline, candidate, revision2, or final');
  if (!existsSync(join(root, arm, 'skills'))) throw new Error(`No frozen ${arm} skills`);
  const variants = (process.env.STUDY_VARIANTS || 'train').split(',');
  const repetitions = Number(process.env.STUDY_REPEATS || manifest.repeats);
  if (!Number.isInteger(repetitions) || repetitions < 1 || repetitions > 3) throw new Error('Repeats must be 1..3');
  const tasks = manifest.tasks.filter(task => variants.includes(task.variant) && (!process.env.STUDY_SKILL || task.skill === process.env.STUDY_SKILL));
  const selectedModels = models.filter(model => !process.env.STUDY_MODEL || model === process.env.STUDY_MODEL);
  const queue = [];
  for (let repetition = 1; repetition <= repetitions; repetition++) for (const task of tasks) for (const model of selectedModels) queue.push({ task, model, repetition });
  await Promise.all(Array.from({ length: 2 }, async () => { while (queue.length) { const item = queue.shift(); await trial(manifest, arm, item.task, item.model, item.repetition); } }));
}
function summary() {
  const grades = existsSync(join(root, 'grades.json')) ? JSON.parse(readFileSync(join(root, 'grades.json'))) : {};
  const records = existsSync(join(root, 'runs')) ? readdirSync(join(root, 'runs')).flatMap(dir => existsSync(join(root, 'runs', dir, 'record.json')) ? [JSON.parse(readFileSync(join(root, 'runs', dir, 'record.json')))] : []) : [];
  const pairs = [];
  for (const baseline of records.filter(r => r.arm === 'baseline')) {
    const candidate = records.find(r => r.arm === 'candidate' && r.skill === baseline.skill && r.variant === baseline.variant && r.model === baseline.model && r.repetition === baseline.repetition);
    if (!candidate || baseline.status !== 'completed' || candidate.status !== 'completed' || !baseline.usage || !candidate.usage || grades[baseline.id]?.pass !== true || grades[candidate.id]?.pass !== true) continue;
    pairs.push({ skill: baseline.skill, variant: baseline.variant, model: baseline.model, repetition: baseline.repetition, baseline: baseline.usage, candidate: candidate.usage, reduction: 1 - candidate.usage.total / baseline.usage.total });
  }
  const groups = [];
  for (const model of models) for (const variant of ['train', 'heldout']) {
    const selected = pairs.filter(p => p.model === model && p.variant === variant);
    const base = selected.reduce((sum, p) => sum + p.baseline.total, 0);
    const candidate = selected.reduce((sum, p) => sum + p.candidate.total, 0);
    groups.push({ model, variant, qualityPassedPairs: selected.length, expectedPairs: 33, baselineTotal: base || null, candidateTotal: selected.length ? candidate : null, reduction: base ? 1 - candidate / base : null, allSkillsCovered: new Set(selected.map(p => p.skill)).size === 11, allExpectedPairsPassed: selected.length === 33 });
  }
  const armOutcomes = Object.fromEntries(['baseline', 'candidate'].map(arm => { const items = records.filter(r => r.arm === arm); return [arm, { total: items.length, completed: items.filter(r => r.status === 'completed').length, executionFailed: items.filter(r => r.status !== 'completed').length, unknownUsage: items.filter(r => !r.usage).length, qualityPassed: items.filter(r => grades[r.id]?.pass === true).length, qualityFailed: items.filter(r => grades[r.id]?.pass === false).length, ungraded: items.filter(r => !grades[r.id]).length }]; }));
  json(join(root, 'summary.json'), { interpretation: 'Matched pass-only savings are conditional; not a full-suite efficiency claim unless every expected pair passes and background isolation is established.', armOutcomes, groups, pairs, excludedRecords: records.length - pairs.length * 2, qualityGradeCount: Object.keys(grades).length });
  console.log(JSON.stringify(groups, null, 2));
}
const command = process.argv[2];
if (command === 'prepare') prepare();
else if (command === 'run') await run();
else if (command === 'summary') throw new Error('Use publication/prepare.mjs for final-arm comparisons');
else if (command === 'freeze-candidate') {
  if (existsSync(join(root, 'candidate'))) throw new Error('Candidate already frozen');
  copy(join(repo, 'skills'), join(root, 'candidate/skills'));
  const manifest = JSON.parse(readFileSync(join(root, 'manifest-final.json')));
  manifest.candidateSkillHashes = Object.fromEntries(files(join(root, 'candidate/skills')).map(path => [path, hash(readFileSync(join(root, 'candidate/skills', path)))]));
  manifest.candidateFrozenAt = new Date().toISOString();
  json(join(root, 'manifest-final.json'), manifest);
  console.log('Candidate frozen; baseline source and prompts unchanged.');
}
else if (command === 'selftest') {
  const complete = parseUsage('{"type":"turn.completed","usage":{"input_tokens":100,"cached_input_tokens":40,"output_tokens":20}}\n');
  if (complete.usage.total !== 120 || complete.usage.uncachedInput !== 60 || parseUsage('{"type":"turn.failed"}').usage !== null || parseUsage('broken').jsonParseErrors !== 1) throw new Error('Usage parser failed');
  console.log('Usage parsing self-test passed; no model call made.');
} else throw new Error('Use prepare, freeze-candidate, run baseline|candidate, summary, or selftest');
