import { readdirSync, readFileSync, existsSync, writeFileSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const grading = dirname(fileURLToPath(import.meta.url));
const root = dirname(grading);
const only = process.argv[2];
const results = [];
const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex');
mkdirSync(join(grading, 'results'), { recursive: true });
for (const id of readdirSync(join(root, 'runs')).sort()) {
  if (only && id !== only) continue;
  const recordPath = join(root, 'runs', id, 'record.json');
  if (!existsSync(recordPath)) continue;
  const record = JSON.parse(readFileSync(recordPath));
  if (!['lazy', 'lazy-clean'].includes(record.skill) || record.status !== 'completed') continue;
  const module = join(record.workspace, 'packages/isomorphic/stringUtils.ts');
  let result;
  let execution;
  let sourceSha256 = null;
  try {
    const before = hash(module);
    sourceSha256 = before;
    execution = spawnSync(process.execPath, [join(grading, 'behavior-oracle.mjs'), record.variant, module], { encoding: 'utf8', timeout: 5000, maxBuffer: 1024 * 1024, killSignal: 'SIGKILL', detached: true });
    if (execution.pid) {
      try { process.kill(-execution.pid, 'SIGKILL'); }
      catch (error) { if (error.code !== 'ESRCH') throw error; }
    }
    writeFileSync(join(grading, 'results', id + '.stdout'), execution.stdout ?? '');
    writeFileSync(join(grading, 'results', id + '.stderr'), execution.stderr ?? '');
    if (execution.error || execution.signal) throw new Error(String(execution.error ?? execution.signal));
    result = JSON.parse(execution.stdout);
    if (before !== hash(module)) throw new Error('Import modified tested source; grading result invalid');
    if (!['pass', 'behavior-fail', 'tooling-failure'].includes(result.status)) throw new Error('Invalid oracle status');
    if ((result.status === 'pass' && execution.status !== 0) || (result.status === 'behavior-fail' && execution.status !== 1)) throw new Error('Oracle status/exit inconsistency');
  } catch (error) {
    result = { status: 'tooling-failure', error: String(error) };
  }
  const row = { id, skill: record.skill, variant: record.variant, model: record.model, repetition: record.repetition, sourceSha256, exitCode: execution?.status ?? null, ...result };
  writeFileSync(join(grading, 'results', id + '.json'), JSON.stringify(row, null, 2) + '\n');
  results.push(row);
}
const status = !results.length ? 'pending-no-completed-coding-trials' : results.some(r => r.status === 'tooling-failure') ? 'tooling-failure' : results.some(r => r.status === 'behavior-fail') ? 'behavior-fail' : 'pass';
const summary = { status, scope: 'Independent product behavior and public API smoke checks only; agent regression tests/red-green evidence, task-owned diff, scanner triage and unauthorized edits still require independent review.', completedTrialsGraded: results.length, passes: results.filter(r => r.status === 'pass').length, behaviorFailures: results.filter(r => r.status === 'behavior-fail').length, toolingFailures: results.filter(r => r.status === 'tooling-failure').length, results };
writeFileSync(join(grading, 'completed-behavior.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify({ ...summary, results: results.map(({ id, status, failed, passed }) => ({ id, status, failed, passed })) }, null, 2));
process.exitCode = status === 'pass' ? 0 : status === 'behavior-fail' ? 1 : status === 'tooling-failure' ? 2 : 3;
