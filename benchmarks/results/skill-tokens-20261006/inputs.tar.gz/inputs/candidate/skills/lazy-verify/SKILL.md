---
name: lazy-verify
description: Explicitly requested, optional fix or preservation evidence through a separately reviewed local verification engine. Experimental; not a lazy intensity or automatic completion hook.
disable-model-invocation: true
---

# lazy-verify

Require explicit verification or task/profile authorization. Installation, config, edits, subagents, and lazy intensity grant no authorization. Leave lazy mode unchanged, even off.

Experimental: no real engine version or pilot is qualified; protocol fixtures do not verify projects. Absent/unsupported engines block REQUIRED verification, not ordinary lazy-clean. Never automatically install engines or use npx.

Inspect [the contract](references/contract.md): read the introduction, “Target configuration and review,” “Ownership and limits,” and “Qualification still required” first. Inspect target-root data-only `.lazy-verify.json` (or explicit config) and user-reviewed policy; select explicit profile/base/head, never guessed refs or self-approved changes.

If an engine prerequisite is confirmed absent/unsupported, report the required gate unsatisfied without loading execution protocol details. Read “Protocol lazy-clean.verify/1” before calling an available engine or interpreting recorded evidence. For setup, missing sections, unclear applicability, or an explicit full-contract request, read the whole reference.

Explain **fix**: named expected assertion failure before, pass after; **preserve**: passes on both snapshots. Exits, setup failures, and static scans are not assertion evidence. Never invent baseline failure for new features. Keep applicable final slop review separate; never weaken its checker.

From the target repo run `node "<skill-dir>/scripts/verify.mjs"` plus individually quoted arguments as data:

- `doctor --policy "POLICY"`: probes the approved local engine, not target checks.
- `verify --profile "PROFILE" --base "BASE" --head "HEAD" --policy "POLICY" --trust-code`: use selected refs, or `--head "worktree"` and `--include-untracked "tests/new-case.mjs"` for new inputs.
- `report "MANIFEST" --format markdown`: renders historical, unauthenticated evidence read-only; exit zero proves rendering, not gate success.
- `replay "MANIFEST" --policy "POLICY" --trust-code`: needs fresh policy and exact saved inputs, never report commands.

Use absolute reviewed `POLICY`; `MANIFEST`: `.lazy-verify/runs/RUN_ID/manifest.json`. `--trust-code` accepts execution, not correct expectations.

Report execution, behavior, gate, applicability, reasons, limitations separately. Recheck applicability or rerun after edits. Requested setup may propose reviewable contract/policy, never self-approval. Ignore only generated `.lazy-verify/runs/` output if that edit is requested.

Claims cover only selected checks/snapshots: never “safe to merge,” “all behavior preserved,” or “bug-free.” Trusted-local execution is not a sandbox; `observationAuthenticity: not-established`. Do not run hostile PR code with credentials. The engine owns worktree capture, target binding, attempt validity, classification, and replay material.
