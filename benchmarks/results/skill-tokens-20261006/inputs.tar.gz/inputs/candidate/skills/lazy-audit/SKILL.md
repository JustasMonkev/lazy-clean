---
name: lazy-audit
description: >
  Whole-repo audit for over-engineering. Like lazy-review, but scans the
  entire codebase instead of a diff: a ranked list of what to delete, simplify,
  or replace with stdlib/native equivalents. Use when the user says "audit this
  codebase", "audit for over-engineering", "what can I delete from this repo",
  "find bloat", "find dead code", "which dependencies can we drop",
  "lazy-audit", or "/lazy-audit". One-shot report, does not apply fixes.
---

Scan whole-repo complexity; rank useful simplifications, preserving required
behavior/features. No edits/mode. Route correctness/security/performance to normal
review. "Apply the findings" uses the lazy ladder and surgical-changes rule.

Detect used TypeScript, JavaScript, Java, Python, Ruby, Rust, and Go. Read each
pinned or installed version from its toolchain file, manifest, lockfile, or
runtime; keep advice compatible. If unavailable, say so; do not guess.
Latest releases only on request for current-version advice. TS/JS and Python: read [TS/JS checks](../lazy/references/simplification-checks.md) and
[Python checks](../lazy/references/python-checks.md) for compatible idioms.

Hunt redundant dependencies, hand-rolled stdlib, dead flags/config, factories,
interfaces, and wrappers without useful boundaries. One caller/export proves
nothing: retain domain names, tricky logic, side effects/boundaries, test/readability
value, and framework contracts; report only if none applies. One implementation
also proves nothing: check details/policy callers would learn; retain consumer-owned
contracts isolating external details or independently changing policy, even forwarding
adapters. Clean scans/fewer lines do not prove design quality.

Keep behavior/edge/failure regression tests. Keep meaningful mutation evidence
when red-green checks do not prove the risk; optional when they do. Never cut
useful evidence for a smaller test tree.

## Findings

Ranked lines: `<tag> <what to cut>. <replacement>. [path]`. Verify paths exist:

- `delete:` dead code, unused flexibility, speculative features; replacement: nothing.
- `stdlib:` hand-rolled library functionality; name the standard function.
- `native:` redundant code/dependency; name the platform feature.
- `yagni:` no useful boundary, unused config, no simpler layer contract.
- `shrink:` same logic, fewer lines; show the shorter form.

End `net: -<N> lines, -<M> deps possible.` Count removable code lines after replacements, not bytes/characters; verify counts; deduplicate cuts/dependencies. Nothing to cut: `Lean already. Ship.`
