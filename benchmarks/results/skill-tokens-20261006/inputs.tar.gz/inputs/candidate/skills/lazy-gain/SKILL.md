---
name: lazy-gain
description: >
  Show Ponytail's upstream benchmark results and lazy-clean's own evaluation
  sources as a compact scoreboard. One-shot display, not a persistent mode
  or a per-repo savings estimate. Trigger: /lazy-gain,
  "lazy gain", "what does lazy save", "show lazy impact",
  "lazy scoreboard".
disable-model-invocation: true
---

Display table with source/setup/limits/local evidence:

| Metric | Ponytail vs no-skill agent |
| --- | ---: |
| Added lines in `git diff` | ~54% fewer |
| Tokens | ~22% fewer |
| Cost | ~20% lower |
| Elapsed time | ~27% less |

Source: [Ponytail, June 18, 2026](https://github.com/DietrichGebert/ponytail/blob/356918eba965ee1eac64bd3a7f0dd02108350de5/benchmarks/results/2026-06-18-agentic.md).
12 FastAPI + React template tasks, Claude Code/Haiku 4.5, four runs/task/arm.
Not reproduced for lazy-clean. Apps not run; added lines prove neither correctness
nor readability. One model/small task set; four timed-out cells lack cost/time.
No savings/safety guarantee.

Local: [runner/measurement rules](https://github.com/JustasMonkev/lazy-clean/blob/main/benchmarks/README.md)
and [Luna guidance pilot/raw artifacts](https://github.com/JustasMonkev/lazy-clean/blob/main/benchmarks/solid-guidance.md).
Pilot: small-task behavior/design; no token/cost/comparable timing or efficiency claim.

Never apply upstream percentages to lazy-clean, this task, or another model.
No invented unwritten-alternative savings. Local gains need actual matched
runner-rule measurements; missing metrics stay unknown.
`/lazy-debt` counts shortcuts; `/lazy-audit` reviews work, neither measures savings.

One-shot: no edits/flag files/persistence/mode change. Dismissal leaves the
active level unchanged, not off.
