---
name: lazy-debt
description: >
  Harvest every `lazy:` comment in the codebase into a debt ledger, so the
  deliberate shortcuts and deferrals lazy leaves behind get tracked instead
  of rotting into "later means never". Use when the user says "lazy debt",
  "/lazy-debt", "what did lazy defer", "list the shortcuts", "lazy
  ledger", "tech debt ledger", or "what did we mark to do later". It tracks
  `lazy:` markers only, not generic TODOs. One-shot report, changes nothing.
---

Report existing comment-prefixed `lazy:` markers only, not TODOs or prose.
Never add markers; new shortcut ceilings/upgrade paths belong in final responses.
Scan excluding dependencies, `.git`, and build output:

`grep -rnE --exclude-dir={node_modules,.git,dist,build,out,coverage} '(#|//|/\*|<!--|--) ?lazy:' .`

Group one row per hit by file:
`<file>:<line>, <what was simplified>. ceiling: <the limit named>. upgrade: <the trigger to revisit>.`

Extract ceiling/upgrade from `lazy: <ceiling>, <upgrade path>`, never invent them.
Tag missing upgrade paths/triggers `no-trigger` (rot risk). Optional owners:
`git blame -L<line>,<line>`.

End `<N> markers, <M> with no trigger.` No hits: `No lazy: debt. Clean ledger.`

One-shot: no mode or writes. Persist only when asked, e.g. `LAZY-DEBT.md`, using
the same row format.
