---
name: lazy-clean
description: Write clean minimal code — the lazy ladder while writing, the slop-check checker after. Use when the user wants BOTH passes on one change, says "lazy-clean", asks for code that is lazy and slop-free, or wants over-engineering and AI slop caught together. For the ladder alone use lazy; for the checker alone use slop-check.
---

# lazy-clean

Apply the lazy ladder while writing, then scan and manually simplify the
task-owned diff. Do not force deletions or cut requested behavior.

## Ladder first

Follow `<skills-dir>/lazy/SKILL.md`, including its verification requirements and
`/lazy lite|full|ultra` intensity. Apply an already-present full injected ruleset
without rereading; a `LAZY MODE ACTIVE` header, description, or compacted summary
is not the ruleset. Read the skill when its body is missing. Carry unfinished
checks through handoffs and compaction.

## Checker and triage

For TS/JS, use the bundled plain-Node checker; no installs or lint configuration
changes. Paths support a focused intermediate scan; `--json` gives findings.
Before finishing, run from the repo root even after edit hooks:

```bash
node "<skills-dir>/slop-check/scripts/check.mjs" --since=HEAD
```

This includes tracked, untracked, and shell edits. Use the task base ref for
committed changes; without Git, pass changed paths as separate quoted arguments.
Triage every finding in your task, preserving pre-existing edits. Exit 0 is clean, 1 means
findings, 2 means a failed scan; never call failure or retained findings clean.

Findings are heuristic: remove real slop or restore real type evidence; leave
genuine false positives unchanged after checking their invariants. Retain a
necessary type assertion or swallowed error only with checked evidence and a
final-response explanation. Never weaken or disable a check to silence it.
Report false positives and retained findings with their checked invariants and reasons.
For finding-specific details, use `--explain=<rule-id>` or the
[slop-check skill](../slop-check/SKILL.md).

Do not add code comments; remove nonessential comments. Keep required license
notices and functional tool directives. Put rationale and constraints in the
final response, never new `SAFETY:`, `lazy:`, or suppression comments.

The scanner reads only TS/JS. Other languages get manual review, not a scanner
cleanliness claim. For HTML inline scripts, extract to temporary JS or report
manual review; zero checked files prove nothing.

## Manual review and evidence

Review dead code, speculative flexibility, impossible-state defenses, repeated
platform/dependency logic, hidden errors, debug leftovers, duplicated edit-artifacts,
comment bloat, and tautological or setup-echo tests. Prefer real dependency seams
over module-level mocks; reject duplicated setup that hides what varies. Do not
create single-use helpers merely to remove comments. Revalidate external data at
trust boundaries rather than removing runtime checks solely because types exist.
One caller alone is not waste: keep domain helpers, tricky logic, side effects,
test seams, readability, and framework contracts. Report only useful findings.

Detect touched languages only: TypeScript, JavaScript, Java, Python, Ruby, Rust, Go.
Read each pinned or installed version from its toolchain file, manifest, lockfile,
or runtime; keep advice compatible. If unavailable, say so and do not guess;
latest-release research is only for current-version requests.
Before finishing TS/JS, apply [TS/JS checks](../lazy/references/simplification-checks.md);
for Python, apply [Python checks](../lazy/references/python-checks.md) and its
configured linter/type checker. Other languages keep their idioms.

Preserve existing accepted input formats and explicit false/zero/empty values;
new formats follow the requested spec without invented formats. Revalidation
does not authorize changing accepted inputs.
Map changed requirements, edge cases, and failure modes to rerunnable tests;
add missing coverage with existing tools. Inline probes alone are not coverage;
trivial edits need no new tests. Keep tests that catch real regressions, not
tautologies or mock setup echoes. Mutation evidence is optional when existing
red-green checks prove the risky regression; otherwise a meaningful mutation can
prove test effectiveness. Never add a dependency for it.

## Conditional workflows

Explicitly authorized behavioral verification follows the independent
[lazy-verify skill](../lazy-verify/SKILL.md) after ordinary review. Its experimental
engine and policy need separate review: never install or execute automatically,
change lazy intensity, replace the final checker, or treat missing prerequisites
as a satisfied required gate. Keep behavioral evidence separate from static findings.

For requested upstream comparisons or ports, read
[upstream updates](references/upstream-updates.md) and the repo's `UPSTREAM.md`
when present. Preserve local behavior and record partial adaptations; a reviewed
upstream revision does not establish a pristine merge base.

## Before you report

Check the diff, not memory:
1. Every requested need is done; nothing unasked was added.
2. Each changed line traces to the request or its verification.
3. Changed behavior has tests that ran; failures are reported.
4. Language checks were applied; checker findings were triaged.
Report changes, checks actually run, and limits. Never claim an unrun check.
