import { readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
const root = '<STUDY_ROOT>';
const paths = JSON.parse(readFileSync(root + '/global-skill-paths.json'));
const args = ['debug', 'prompt-input', '-c', 'project_doc_max_bytes=0', '-c', 'skills.config=[' + paths.map(path => '{path=' + JSON.stringify(path) + ',enabled=false}').join(',') + ']', '-c', 'features.multi_agent=false', 'isolation audit'];
const result = spawnSync('codex', args, { cwd: root, encoding: 'utf8' });
writeFileSync(root + '/prompt-audit-disabled.json', result.stdout);
writeFileSync(root + '/prompt-audit-disabled.stderr.log', result.stderr);
console.log(JSON.stringify({ status: result.status, bytes: result.stdout.length, stderr: result.stderr.slice(0,500), argv: args }));
