---
name: test-quality-review
description: Audit an entire test suite, or explicitly scoped recent tests, for pointless assertions, implementation coupling, and weak oracles. Report evidence for a separate fresh-context, tests-only fixer. Not for routine test execution.
---

# Test Quality Review

Review what tests prove, not assertion counts. Report only: never edit tests or
production. Requested fixes go to a separate fresh-context agent.

## Establish coverage

Default to the entire suite, not a PR/sample: inventory unit, integration,
end-to-end, generated and parameterized cases and inspect runner configuration.
Exclude dependencies, build copies and vendored suites unless requested; report
exclusions. Recent additions can come first, but never silently stop there.

For explicit recent-only scope, establish the supplied base/date or session
range; ask if the boundary is missing, never invent it. Read relevant older
tests/production for context without expanding edits or cleanup. Bare invocation
still means the whole suite. Maintain per-suite/file reviewed, remaining,
excluded and blocked records through bounded batches and handoffs. Completion
requires no unread requested scope. Review does not imply installs or full-runner
execution.

Batch independent reads/checks with separate exits/results; reuse evidence only
for unchanged inputs/environment. Read extra context for contract/oracle/configuration
uncertainty.

## Trace each oracle

Follow workspace retrieval instructions. Read relevant setup, exercised code and
public/collaborator contracts; names/comments are claims, not coverage evidence.
For each suspect assertion establish:

- Required behavior, code exercised and actual/expected value origins.
- A plausible incorrect implementation that passes, or a legitimate refactor
  that fails without breaking the contract.
- Whether other assertions already protect the missing behavior.

Validate would-pass faults against exact values and the whole test, including
later assertions; otherwise label a hypothesis. No bug quota; review stays read-only.

Judge the whole test before calling it valueless. Exception expectations,
snapshots, fixture checks and mock verification can be valid oracles without
conventional assertions. Account for async execution and whether assertions run.

## Findings need counterexamples

**Tautology/setup-only:** self-comparisons, literals constructed by the test and
fixture checks may never exercise the subject. Explain why an incorrect subject
cannot change the outcome; useful arrangement diagnostics are not subject proof.

**Mock echo:** configuring and asserting a collaborator result can be weak, but
forwarding itself may be required. Trace arguments, routing, order, awaiting,
errors and forbidden calls. Do not categorically reject mocks/interactions;
identify whether the test catches a wrong dependency or constant return.

**Private/source coupling:** show an allowed refactor rejected by tests of private
helpers, fields, source or incidental ordering. Exported interfaces, generated
artifacts and prohibited dependencies can be intentional structural contracts.
Private access alone is not proof of uselessness; separate coupling from coverage.

**Copied implementation oracle:** identify the correlated fault when expectations
repeat the subject's algorithm/branches or use it to calculate answers. Similar
syntax, trusted independent references, contract tables and specified shared
constants are not automatically copying. Prefer hand-derived cases, independent
references or fault-excluding properties. Round trips/metamorphic properties can
miss paired/common-mode faults; state their limits.

**Weak oracle:** truthiness, type, presence, length or no-exception can be useful
smoke coverage but miss the named behavior. Give a wrong value/side effect that
passes, and strengthen the missing behavior without discarding useful checks.
Weak/incomplete is not the same as valueless.

## Preserve contracts

Schemas, serialization, types, nullability and required keys may be the tested
behavior; do not dismiss them as implementation detail or replace them with an
unrelated value check. Separate schema and semantic coverage; request both only
when the contract needs both. Exact comparisons/snapshots protect reviewed stable
contracts and are brittle when freezing incidental details: establish which.

Do not invent requirements to strengthen tests. Qualify unclear contracts and
state missing evidence. Before consolidating/removing a redundant-looking test,
check whether it protects an independently important scenario.

## Evidence and handoff

For each finding provide location, actual guarantee, concrete passing
counterexample/allowed refactor and **keep**, **strengthen**, **replace** or
**delete** action. Prioritize missed-behavior consequences, not syntax. Separate
demonstrated failures from reasoned counterexamples and label uncertainty.
Deletion without replacement requires the whole test to protect no meaningful
behavior; explain why none of its checks depends on the contract. Preserve
useful checks in mixed tests. Prefer focused missing cases over blanket rewrites,
assertion quotas or automatic deletion.

Relevant tests/isolated probes are optional within authorization; no production
mutations or mutation campaigns in this read-only review. Report actual runs and
unverified scope. Apply the same reasoning across languages, including Python
assert/unittest/pytest/mock forms, with installed compatible tools. A TS/JS scan
cannot establish Python test quality. Matches are candidates, not oracle analysis.

End with the coverage record and consolidated prioritized report: revision/worktree,
test names/locations, contracts, production entry points, evidence, uncertainty
and coverage to retain. Make it self-contained without the review transcript.

Only when fixes are requested, start a separate fresh-context agent with this
report, repository/scope and [fixer instructions](references/fixer-handoff.md).
Never switch the reviewer into editing or send its chat history/old benchmark
results to the fixer. If clean-context delegation is unavailable, supply the
handoff for a new session; do not pretend this context is fresh.
