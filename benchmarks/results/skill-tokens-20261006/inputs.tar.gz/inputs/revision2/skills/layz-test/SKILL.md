---
name: layz-test
description: >
  Find and reproduce bugs across applicable layers, add behavioral coverage, run the
  checks, and finish with manual testing steps and why automation cannot settle
  them. Use when asked to fully test code, assess test coverage, identify manual
  testing gaps, or invoke layz-test. Use existing tools; no benchmark framework.
---

# layz-test

Test requested scope with the smallest useful checks. One-shot; no mode/hook changes.
Passing tests never establish exhaustive coverage, bug-free code or release readiness.

## Scope and behavior

Read repo instructions, requirements, code, callers and tests. Scope to requested
files/diff; otherwise inventory components/suites. State scope, revision,
assumptions and finish criteria before checks. Whole-repo requests cover every
component, never a silent sample. Reuse pinned/installed tools, runners,
fixtures, assertions and dependencies; read versions. Do not download tools or
add frameworks merely to measure this workflow. For checks that rely on locked dependencies,
use the repository's documented locked install in a disposable copy when permitted;
otherwise report those checks as blocked.

Batch independent reads/checks with separate exits/results, preserving assertion order;
reuse evidence only for unchanged inputs/environment.

Map behavior → test → result: happy paths, false/zero/empty, invalid inputs,
failures; relevant retries, replay/restore, cancellation, concurrency and cleanup.
Use contract/requirement oracles, not implementation copies; label uncertainty.
Honor exclusions, including no-security requests, even in bundled suites.
Consider every other layer and domain risk; run applicable checks, explaining
blocked/not-run/not-applicable outcomes.

| Layer | Applicable checks |
| --- | --- |
| Static/build | Lint/types/build/package/API; formatters in check or dry-run mode. |
| Unit/property | Branches, bounds, invalid inputs, generated invariants. |
| Integration/contract | Dependencies, serialization, persistence, errors. |
| E2E/UI | Critical flows/navigation, keyboard, browsers/devices. |
| Resilience | Timeouts/retries/races/cancellation, partial failure/cleanup. |
| Security | Validation/auth, secrets, injection/paths. |
| Accessibility/visual | Automated accessibility/visuals, human usability. |
| Performance | Budgets, realistic limits, leaks/resource bounds. |

## Execute in captured copies

Use the host's existing execution sandbox and permissions; a disposable copy is not a security sandbox.
Use disposable copies for installs, mutation probes, old-code reproductions and any
command expected to write repository state, including snapshots, fixtures, and coverage.
Capture a stable source revision or snapshot containing the requested inputs, including relevant uncommitted edits.
Verify source bytes and behavior-relevant metadata, such as executable modes, against that captured state before execution; block checks whose required state cannot be captured or reproduced.
Use independent regular source files, not links or Git metadata shared with the user's checkout.
Do not follow links when preparing a probe; report checks requiring linked or special-file source inputs as blocked.
Do not copy production credentials, user home state, or Git history and configuration into a probe.
Use fixtures/sandbox credentials; record revision, uncommitted inputs/omissions.
With missing inputs/isolation, report the check as blocked.
Do not reconstruct user Git, home, or filesystem state or run destructive probes in place.

Run non-interactively, never in watch mode, with a timeout and a bounded workload.
Run each command only where the host can manage its spawned process tree; otherwise report the check as blocked.
Terminate that tree on success, failure, timeout, cancellation, and partial setup.
Clean up listeners, timers, temporary copies, and mutations on those exits; report cleanup failures.
Keep setup services alive until their dependent checks finish. Isolate test data;
authorize destructive/costly external checks, never invent credentials.
Never call a live payment, email, SMS, or other third-party account unless it is an isolated sandbox or the user approves.
Otherwise report blocked automation.

Do not automatically copy generated files back.
Apply test and snapshot changes through ordinary scoped edits after review,
preserving existing user changes; if unsafe, save a redacted patch and report the conflict.
Keep redacted evidence the report cites outside disposable copies before deleting them; report its path.

## Challenge and prove

Run existing relevant tests first; save behavioral/negative tests against real
code for every applicable requested case and changed boundary, including accepted
zero/empty. Counts/line coverage are not proof. Challenge caller/contract
hypotheses with boundaries, malformed/generated inputs and adverse event order;
use independent oracles/invariants and follow suspicious results through callers.

Confirm each bug with a minimal failing assertion on the unmodified code:
record contract, input/events, expected/actual and caller. Separate defects,
unclear requirements, environment failures and synthetic mutations; never invent a finding.
With none confirmed, report tested hypotheses. Fix product defects only when
requested; supplied files/diffs authorize testing, not fixes. Otherwise retain
the failing reproducer. Never weaken assertions, skip failures or change behavior
for green; separate pre-existing/new failures.

Discovery reproducers alone are not paired effectiveness proof. Existing intended
red/green evidence covering the risk needs no extra mutation; otherwise use:

- The same new test, unchanged, in a disposable copy against the relevant
  pre-fix product state needed for that behavior, including dependencies/config:
  its intended assertion fails there and passes against the fix. If that state
  is unavailable, report regression proof as blocked.
- Alternatively, in a disposable copy, leave a passing test unchanged, mutate a relevant production branch/boundary,
  observe its intended assertion fail; revert and rerun green. A mutation of the test itself or a setup/import failure is not proof.

One representative meaningful probe can cover the risk. Test-only tasks permit
production mutations only in captured copies to challenge unchanged passing
tests; never apply unasked product fixes.
Check the task-owned diff; preserve user edits and report
unrelated changes. If source changed after testing, rerun affected checks or report the newer state as untested.
Rerun after test edits; installed TS/JS slop-check is static, not behavioral evidence.

## Report and manual checks

Before saving, applying, or sharing commands, results, logs, evidence, patches, tests, or snapshots, redact credentials and sensitive data.
Use rerunnable placeholders; name redactions, never original values. If unusable,
report the affected output as blocked.

Report revision/worktree/environment, test changes, behavior table, exact
commands/exits/assertions and log/evidence paths. Use **pass**, **fail**, **blocked**,
**not run**, **not applicable**. Record skips/retries; a flaky pass does not erase an earlier failure.
Planned/empty/blocked runs are not tested; always state remaining coverage/uncertainty.

End with **Manual testing still needed**:

| Check | Steps and expected result | Why automation cannot settle it here | How to enable automation, if possible |
| --- | --- | --- | --- |

Separate human judgment (usability/screen readers/hardware) from missing
browser/service/credentials/OS/dependency automation. Give exact blockers and
rerunnable commands/prerequisites, not unrelated checklists. If no human checks
apply, say so; list blocked automation separately. Never claim nothing needs
testing without evidence for scope, including untested behavior.
