---
name: lazy
description: Use for coding tasks, bug fixes, refactors, code reviews, or requests for lazy mode, simpler code, or less over-engineering. Not for unrelated prose or general knowledge.
argument-hint: "[lite|full|ultra]"
license: MIT
---

# Lazy

Correctness and scope outrank size; complete the clearest small solution.
Before coding, state material assumptions, interpretations, and tradeoffs; ask
only for blocking information. Multi-step work needs a step → check plan and
verifiable finish: bugs go red → green; refactors get before/after checks.
Loop until verified. Carry unfinished checks through handoffs and compaction;
summaries do not replace these instructions.

Batch independent reads and checks, preserving each result
and required before/after order. Reuse already-read unchanged evidence; do not
reload unrelated language guidance, dependencies, or benchmark reports.

## Persistence

Keep the level until `/lazy off`, "stop lazy", or "normal mode". Switch with
`/lazy lite|full|ultra`; bare `/lazy` only reports the level.
Do not announce the mode during ordinary work.

## The ladder

Trace affected code, callers, callbacks, retries, restore/replay, and concurrency;
fix the shared cause. Skip speculative work, never requirements. Reuse helpers or patterns,
stdlib, native features or installed dependencies before clear small new code.
No avoidable dependency or unrelated cleanup.

Match style; preserve unrelated edits. One caller alone is not waste: keep domain
names, tricky logic, side effects, test seams, readability, and framework contracts.
Reject speculative features/config, needless abstractions, and impossible-state
guards; offer simpler options. Review the task-owned diff: remove only task-created
orphans and unasked additions; mention unrelated dead code. Simplify structure,
not formatting; never force a net-negative diff or cut required behavior.

Do not add code comments; remove nonessential comments. Keep required license
notices and functional tool directives. Report rationale, constraints, checked
invariants, shortcut ceilings, and upgrade paths in the final response.
Never add `SAFETY:`, `lazy:`, or `slop-check-ignore`; verify necessary functional suppressions.

## Boundaries and checks

Group behavior by reason to change; keep policy independent of external details
through ordinary parameters; give callers needed capabilities. Extend existing
contracts for requested variations. Interchangeable implementations preserve
inputs, results, errors, and lifecycle; test the same contract against each.
No interfaces merely for SOLID. For boundary changes, read
[design checks](references/design-checks.md). One implementation alone is not waste;
judge behavior and design separately.

Preserve defaults, explicit false/zero/empty values, accepted input formats, user
state, errors, metadata, generated files, lockfiles, and platform behavior unless
requested otherwise. Keep security, accessibility, and real-hardware calibration.
Revalidate at trust boundaries; bound external work and clean up timers, listeners,
and tasks.

For languages in use only (TypeScript, JavaScript, Java, Python, Ruby, Rust, Go),
read the pinned or installed version from its toolchain file, manifest, lockfile,
or runtime; keep advice compatible. Report unavailable facts; do not guess.
Research latest versions only when asked for current-version advice. Before finishing, read relevant
[TS/JS and tsconfig checks](references/simplification-checks.md) or [Python checks](references/python-checks.md);
read only the changed language's reference. Other languages keep their idioms.
For non-trivial code changes, read relevant [risk checks](references/risk-checks.md).

Use existing tests. Map changed requirements, edge cases, and failure modes to
rerunnable tests; add missing coverage. Inline probes alone are not coverage.
Trivial edits need no new tests; testing requests cover the full case list.
Save applicable zero/empty and boundary cases, not just representative happy paths.
Mutation is optional when red-green checks prove the risky regression; otherwise
a meaningful mutation can provide evidence. Never add a dependency for it.

For TS/JS, finish with the checker from the repo root, even after edit hooks:
`node "<skills-dir>/slop-check/scripts/check.mjs" --since=HEAD`.
The skills directory contains sibling skill folders, not this
`lazy` folder. Execute the checker; use `--explain` for details,
not implementation/test-source dumps unless diagnosing a concrete issue.
Use the task base ref when committed, or individually quoted changed paths without
Git. Triage only task-owned findings; failed scans are not clean. Never weaken or
disable checks to silence findings.

## Intensity

<!-- Mode-keyed rows and quoted examples are filtered by lazy-instructions.js. -->

| Level | What changes |
|-------|------------|
| **lite** | Complete the task; suggest a simpler option when useful. |
| **full** | Apply the ladder. Default. |
| **ultra** | Cut unasked extras, never requested behavior or checks. |

Example: "Add a cache with a 60-second expiry."
- lite: "Keep expiry; suggest the existing helper."
- full: "Reuse the helper; keep 60-second expiry."
- ultra: "Keep expiry; skip unasked metrics/configuration."

## Before you report

Check the diff, not memory:
1. Every requested need is done; nothing unasked was added.
2. Each changed line traces to the request or its verification.
3. Changed behavior has tests that ran; failures are reported.
4. Language checks were applied; checker findings were triaged.
Report changes, checks actually run, and limits. Never claim an unrun check.
