---
name: lazy-review
description: >
  Code review focused exclusively on over-engineering. Finds what to delete:
  reinvented standard library, unneeded dependencies, speculative abstractions,
  dead flexibility. One line per finding: location, what to cut, what replaces
  it. Use when the user says "review for over-engineering", "what can we
  delete from this diff", "is this over-engineered", "simplify review", or invokes
  /lazy-review. Complements correctness-focused review, this one only
  hunts complexity.
---

Review only task-owned diff complexity; no edits/mode. Route correctness,
security, and performance to normal review. Preserve requested features/behavior;
never manufacture net-negative diffs.
"Apply the findings" uses the lazy ladder and surgical-changes rule.

Detect touched TypeScript, JavaScript, Java, Python, Ruby, Rust, and Go. Read each
pinned or installed version in a toolchain file, manifest, lockfile, or
runtime; keep replacements compatible. If unavailable, say so and do not guess.
Latest releases only for requested current-version advice. For TS/JS, read
[TS/JS checks](../lazy/references/simplification-checks.md); for Python, read
[Python checks](../lazy/references/python-checks.md). Read only the touched
languages' references and needed version facts, not whole dependency inventories.
Batch independent relevant context reads. Review the actual diff before reporting;
do not load unrelated benchmark evidence or manufacture findings.

Before `yagni:`, `shrink:`, or `delete:`, retain domain names, tricky logic,
side-effect/boundary isolation, test/readability value, and framework contracts.
One caller or production implementation proves nothing: check details/policy
callers would learn; retain consumer-owned contracts isolating external details
or independently changing policy, even forwarding adapters. Clean scans/fewer
lines do not prove design quality.

Keep behavior/edge/failure regression tests. Keep meaningful mutation evidence
when red-green checks do not prove the risk; optional when they do. Never cut
useful evidence for a smaller test tree.

## Findings

`L<line>: <tag> <what>. <replacement>.`; prefix `<file>:` for
multi-file diffs. Verify cited files/lines in the diff.

- `delete:` dead code, unused flexibility, speculative features; replacement: nothing.
- `stdlib:` hand-rolled library functionality; name the standard function.
- `native:` redundant code/dependency; name the platform feature.
- `yagni:` no useful boundary, unused config, no simpler layer contract.
- `shrink:` same logic, fewer lines; show the shorter form.

Examples:

- `L12-18: stdlib: clamp with finite numbers and min <= max enforced. Math.min(Math.max(value, min), max), preserving bounds.`
- `L4: native: moment.js only for en-US/UTC medium dates. Intl.DateTimeFormat('en-US', { timeZone: 'UTC', dateStyle: 'medium' }), preserving format.`
- `repo.py:L88: yagni: SQLite forwarding wrapper. Call directly only if the consumer owns the database detail; preserve transaction/dependency boundaries.`
- `L30-34: shrink: unchanged forwarding to parseInt, radix 10. Call parseInt directly with radix 10.`
- KEEP: transaction helper owns rollback, tested even with one caller.

End `net: -<N> lines possible` only for real removable code lines after
replacements, not bytes/characters; otherwise `net: unchanged` when required
features remain. Nothing to cut: `Lean already. Ship.` and stop.
