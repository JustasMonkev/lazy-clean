# Candidate heldout independent quality grading

Scope: all 66 original candidate heldout cases, 11 skills × 2 models × 3 repetitions. All records terminal: 64 completed, 2 lazy repetition-3 timeouts. No sampling; no baseline/train grades, prior grades, token savings, proposals, or revision2 inspected. Frozen manifest task criteria and original candidate skill contracts only.

Result: **45 pass, 21 fail, 0 pending**. Benchmark quality pass is not CLI success, product correctness alone, release readiness, or actual lazy-verify behavioral gate satisfaction. Honest blocked verification can be a quality pass while the required gate stays unsatisfied.

## Counts

| Skill | Pass | Fail |
|---|---:|---:|
| layz-test | 3 | 3 |
| lazy | 2 | 4 |
| lazy-audit | 5 | 1 |
| lazy-clean | 3 | 3 |
| lazy-debt | 6 | 0 |
| lazy-gain | 3 | 3 |
| lazy-help | 4 | 2 |
| lazy-review | 4 | 2 |
| lazy-verify | 4 | 2 |
| slop-check | 6 | 0 |
| test-quality-review | 5 | 1 |

## Evidence and decisions

Every case has pass/reasons/evidence in grades-candidate-heldout.json. Actual record, prompt, stdout completed commands/messages, diff, untracked inventory and relevant workspace artifacts were inspected. Saved escaping tests and captured mutation/final logs were reviewed; all completed lazy/lazy-clean products pass the read-only independent heldout oracle (27/27), but incomplete saved edge coverage fails the separate frozen criterion. Both timed-out lazy sources remain original and fail 7 behavioral oracle checks; no retry or elapsed/usage inference was performed. Overnight elapsed values are invalid and missing metrics are unknown.

No new universal execution/test gate was imposed on read-only reviews. Slop candidate final --since requirement applies before finishing edits, so read-only requested-module scans suffice; all six actual module scans establish six findings in one file, not an assumed two casts and not a clean scan. In layz-test, retained discovery assertions count as successful discovery, but the original explicit separate effectiveness requirement needs an unchanged passing test red under a feasible production mutation or paired old/fix proof. All Sol escaping cases supply it; none of the Luna cases does.

Audit line reductions were checked after replacement, not counted by casts; Luna audit rep3 cannot support net -3 lines. Seeded review simplification restores the original unbraced guard/direct return, exactly four fewer lines; Luna review rep1/2 incorrectly claim five. Help whole-card scope includes commands, hosts and default precedence despite the prompt explicitly mentioning levels/deactivation. Gain retains full locally supplied upstream setup and limitations; omitted apps-not-run is material, while savings remain unknown and are not transferred.

TQR Luna rep3 inaccurately calls code-point-only cap measurement a changed-output fault. The other supplied Unicode/escaping/URL counterexamples were checked against the complete five-test suite and later assertions; no mutation campaign required. TQR Luna rep1 has minor wrong test line numbers but correctly identifies functions, real oracle behavior and concrete valid missed faults; this was not used to invent a new all-line-perfect gate.

Lazy-verify Luna rep1 invokes the bridge against external policy paths despite workspace-only bounds and overstates the doctor disjunction as proof Node is absent. Luna rep3 explicitly probes the outside engine path. Other verification outputs correctly infer the engine absence supplied by the user without inventing command results or substituting static/harness success for fix evidence. Setup/protocol failures are not behavioral assertion evidence. Existing verifier config/policy untracked files are seeded inputs, not mutations.

Only this grade file and this notes file were written. Independent behavior oracle reads modules without modifying captured workspaces. No network, install, new agent, global state or product mutation by this grader.
