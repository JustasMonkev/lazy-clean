---
name: slop-check
description: Detect and remove AI slop — pointless, low-evidence, or filler code — in TypeScript and JavaScript. Use after writing or editing TypeScript or JavaScript, when reviewing a diff or pull request, or whenever the user asks to check for slop, clean up AI-generated code, or run slop-check. Fully self-contained; runs with plain node and requires no npm packages or project configuration.
---

# slop-check

Remove fabricated type evidence, pointless code, filler comments, and edit-artifacts. Run plain `node` from this skill; do not install packages, copy files into the repository, or change lint configuration.

## Run and triage

```bash
node <skill-directory>/scripts/check.mjs [paths...]
```

No paths scans the current directory recursively, excluding `node_modules`, build output, and agent tooling. Before finishing edits, run from the repo root with `--since=HEAD`, even after edit hooks: tracked, untracked, and shell changes are included. Use the task base ref for committed changes; triage only task-owned findings, not pre-existing user edits. Without Git, pass changed paths as separate quoted arguments, never shell word splitting.

- `--since=<git-ref>` reports findings only on added diff lines; use `HEAD` before commit or `origin/main` in CI.
- `--json` gives machine-readable findings. `--summary` replaces findings with per-rule tallies; the run summary still prints.
- Exits: **0** clean, **1** findings, **2** unreadable path/failed scan. Report failures as failures.
- `--disable=<rule-id>[,<rule-id>]` disables named rules for that run. Unknown IDs warn on stderr without narrowing the scan. Never disable or weaken checks to silence findings.
- `--explain=<rule-id>` prints why, slop/instead examples, and false-positive guidance, then exits without scanning; unknown IDs exit 2. Use it when judging a finding.

Only TypeScript/JavaScript are scanned. For other languages, skip the checker and use the manual review; an unread language cannot be called clean. HTML is not scanned: extract affected inline `<script>` code to temporary `.js`, or perform and report manual review. Zero files checked is no coverage, never a clean verdict.

Findings are heuristic review prompts, not verdicts. Triage every one: fix real slop or restore type evidence through inference, `as const`, `satisfies`, owner contracts, or boundary parsing. Leave genuine false positives unchanged; never worsen correct code to appease the scanner. Retain necessary assertions or swallowed errors only after checking their invariants. Report findings, fixes, retained findings, reasons, and checked invariants; a retained finding is not a clean scan.

Do not add code comments; remove nonessential comments from code you touch. Keep required license notices and functional tool directives. Put rationale and constraints in the final response, never new `SAFETY:`, `lazy:`, or suppression comments. Existing `SAFETY:` and `slop-check-ignore` directives remain supported for compatibility; do not add them.

## Versions and manual review

Detect only languages in use: TypeScript, JavaScript, Java, Python, Ruby, Rust, Go. Read each pinned or installed version from its toolchain file, manifest, lockfile, or runtime; keep advice compatible. If unavailable, say so and do not guess. Research latest releases only for requested current-version advice.

Apply [TS/JS checks](../lazy/references/simplification-checks.md) for TypeScript version/tsconfig, module shape, and type modeling. For Python, apply [Python checks](../lazy/references/python-checks.md) and run the project's configured linter and type checker. Review the same scoped code manually:

- Delete unused exports/parameters, unreachable branches, commented-out code, unasked config, and speculative flexibility only when genuinely unnecessary. One caller alone proves nothing: retain domain names, tricky logic, side-effect boundaries, test seams, readability, and framework contracts; inline only when none earns its place.
- Remove impossible-state defenses, redundant same-boundary validation, and unnecessary optional chaining. Keep runtime validation after parsing, persistence, redirects, or other trust boundaries; types do not validate external input.
- Replace reimplemented platform/stdlib utilities with native features or existing project helpers. Check hidden errors: catch-log-continue, non-transient retries, and fake-success fallback values.
- Cut debug tracing/timing, temporary debug names, duplicate old/new implementations, unnecessary compatibility aliases, and comments describing edits. Remove narration, signature-restating JSDoc, and section banners. Prefer clearer names/control flow; never add single-use helpers merely to remove comments. Explain tricky ordering and constraints in the final response.
- **Python slop**: bare `except:`, `except Exception: pass`, mutable defaults, falsey checks on valid zero/empty strings, unstructured dictionaries, grab-bag `utils.py`, import-time work. Verify existing functional `# type: ignore`/`# noqa` directives and necessary additions against the named diagnostic; explain evidence in the final response. Never add them merely to silence findings.
- Review setup-only mock assertions, module-level mocks without real seams, and duplicated setup hiding variation. Keep tests that catch real regressions; mutation evidence is optional when existing red-green checks already prove the risky behavior.

One production implementation is not waste. Before removing a boundary, check which external details and independent reasons for change its callers would inherit. Keep consumer-owned contracts and narrow capabilities; judge behavior and design separately.

## Array review limits

Array performance (review only): `no-reduce-accumulator-copy`, `no-array-filter-map`. Growing accumulator copies can be quadratic; mutate only fresh, locally owned accumulators. Merging passes can change callback order, indexes, sparse-array behavior, and side effects. Neither rule auto-rewrites or proves runtime array identity.

Coverage: dotted calls, inline reducers, simple immutable aliases and array annotations. Excluded: computed methods, named reducer callbacks, nested reducers, indirect copy helpers, complex nested generic array annotations, ambiguous bindings. Repeated binding names across scopes can suppress findings; expressions beyond the bounded scanner window are skipped.

The full [rule inventory](references/rules.md) is needed only to look up rule IDs, not for routine scanning or triage; use `--explain` for a finding’s rationale.
