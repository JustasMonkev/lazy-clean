## Checker rule inventory



Type evidence: `no-any`, `no-chained-type-assertions`, `no-unknown-alias`, `no-object-type`, `no-unsafe-dictionary-type`, `no-known-value-widening`, `no-empty-type-declaration`, `no-reflect`, `no-shape-in-symbol-names`, `require-safety-comment-for-type-assertion`.

Pointless code: `no-useless-rethrow`, `no-empty-catch`, `no-catch-fake-success`, `no-log-and-rethrow`, `no-message-only-rethrow`, `no-json-clone`, `no-redundant-fallback`, `no-boolean-literal-compare`, `no-boolean-literal-ternary`, `no-boolean-return-branches`, `no-double-negation-condition`, `no-await-promise-resolve`, `no-promise-constructor-wrapper`, `no-conditional-empty-object-spread`, `no-let-if-else-assign`, `no-foreach-push`, `no-slop-symbol-names`.

Faked behavior and test slop: `no-arbitrary-sleep`, `no-env-secret-fallback`, `no-module-mocking`, `no-tautological-assertion`.

Array performance (review only): `no-reduce-accumulator-copy`, `no-array-filter-map`.

Comment slop: `no-filler-comments`, `no-narration-comments`, `no-change-note-comments`, `no-backcompat-comments`, `no-restating-comments`, `no-obvious-doc-comments`, `no-typed-jsdoc`, `no-unjustified-suppression`, `no-unjustified-ignore`, `no-emoji`.
