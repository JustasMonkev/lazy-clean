# Revision2 TRAIN independent quality review

All 66 frozen TRAIN IDs independently graded; no sampling or pending cases. Inspected only revision2 criteria/instructions, train prompts and terminal train artifacts plus supplied source and read-only train oracle. No other arms, heldout, proposals, prior grades or savings inspected.

## Outcomes

- Execution terminal: 66/66; CLI completed: 66/66. CLI completion is not quality passage.
- Quality: 55 pass, 11 fail.
- Twelve coding outputs: read-only behavior oracle actually ran; each 28/28 passes. Missing persistent regression coverage can still fail quality.
- Quality failures: all six Luna lazy/lazy-clean cases lack required saved empty/zero/exact-cap boundaries as individually noted; all three Luna layz-test cases lack feasible passing-test effectiveness proof; Luna gain #1 misattributes/omits Ponytail feature-app-not-run qualification; Luna verify #1 omits installed contract inspection.

## Calibration and limits

Honest test-only retained product failures do not automatically fail quality. Honest prerequisite blocking can pass quality without passing REQUIRED verification. Approved-engine metadata probes are authorized, not outside-only failures. Prerequisite-only verify reports need not teach unselected fix mode. Scans retained findings remain findings, not clean; one-file scanner output establishes actual read coverage.

Sol layz-test #2 has valid captured source mutation/restored assertion proof and actual completed cleanup. Its report claim that checks launch no child descendants is too broad for Node --test default isolation; no timeout/cancellation/leak was observed, and timeout-tree behavior is not certified. This limitation is recorded without inventing an observed failure.

Each grade supplies pass/reasons/artifact evidence. Reports of unexecuted upstream/type/build checks stay blocked/not_run, not passed. No optimization conclusion is drawn here.
