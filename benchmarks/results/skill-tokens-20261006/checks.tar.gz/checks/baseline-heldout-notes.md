# Independent baseline heldout quality review

All 66 baseline heldout cases reviewed individually: **49 pass, 17 fail**. No sampling, candidate artifact inspection, token-efficiency grading or CLI-completion-as-success inference. Frozen manifest heldout criteria and original baseline skill contracts govern verdicts.

Scope is the bounded five-file Playwright snapshot. Seven heldout task families are substantively novel; audit/debt/gain/help are repeat/framing checks, not transfer evidence. Pass for lazy-verify means the agent correctly reported the required gate blocked; no actual project behavioral verification passed. Honest retained failing defect reproducers are successful discovery when the full testing workflow is satisfied.

Independently executed the read-only heldout behavior oracle on all 12 lazy/lazy-clean modules: 27/27 checks passed in every case. Grading failures in those cases concern mandatory saved tests/checker workflow, not observed implementation defects. No run workspace was modified.

The JSON artifact carries per-ID command/exit summaries, source/diff scope and reasons. A malformed physical JSONL event in layz-test Luna repetition 2 was not accepted as complete execution evidence; retained source, final report and complete neighboring events remain available. Task-provided gain source documents were inspected only as the evidence inputs of that task, not as this experiment's quality results.

Minor presentational imperfections alone do not fail cases. Required omitted behaviors, scans, unsupported proposed cuts and concrete false behavioral counterexamples do. Conditional audit recommendations are not treated as unconditional adoption claims.

| Case | Grade | Rationale |
|---|---|---|
| baseline--layz-test--heldout--gpt-6-luna--1 | FAIL | No paired pre-fix/fix or meaningful unchanged-passing-test production mutation proof, and no concrete feasibility blocker, despite dependency-free copied-source mutation being feasible.; Installed slop checker was available but no post-test-edit scan ran.; CR-to-LF template parsing is classified as a confirmed defect without establishing cooked newline preservation contract or a caller; uncertain contract was not separated from actual interpolation discovery. |
| baseline--layz-test--heldout--gpt-6-luna--2 | FAIL | No paired pre-fix/fix or meaningful unchanged-passing-test production mutation proof, and no concrete feasibility blocker, despite dependency-free copied-source mutation being feasible. |
| baseline--layz-test--heldout--gpt-6-luna--3 | FAIL | No paired pre-fix/fix or meaningful unchanged-passing-test production mutation proof, and no concrete feasibility blocker, despite dependency-free copied-source mutation being feasible.; Installed slop checker was available but no post-test-edit scan ran.; CR-to-LF template parsing is classified as a confirmed defect without establishing cooked newline preservation contract or a caller; uncertain contract was not separated from actual interpolation discovery. |
| baseline--layz-test--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--layz-test--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--layz-test--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy--heldout--gpt-6-luna--1 | FAIL | Required rerunnable edge coverage incomplete: no empty-payload or multiple-comma/first-comma assertion; successful implementation oracle does not replace saved regression coverage.; Saved case-insensitivity regression covers mixed case only, not uppercase scheme.; Original lazy contract requires final bundled --since=HEAD checker; none was run. |
| baseline--lazy--heldout--gpt-6-luna--2 | FAIL | Required rerunnable edge coverage incomplete: no empty-payload or multiple-comma/first-comma assertion; successful implementation oracle does not replace saved regression coverage. |
| baseline--lazy--heldout--gpt-6-luna--3 | FAIL | Required rerunnable edge coverage incomplete: no empty-payload or multiple-comma/first-comma assertion; successful implementation oracle does not replace saved regression coverage.; Required checker attempted at wrong lazy/scripts path and failed MODULE_NOT_FOUND; bundled slop-check script was actually present, so reported absence is unsupported and no final valid scan ran. |
| baseline--lazy--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-audit--heldout--gpt-6-luna--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-audit--heldout--gpt-6-luna--2 | FAIL | Only finding supplies neither exact shorter indexed polling replacement nor justified removable-line tally; empty intervals, explicit zero intervals, repeated-last fallback and ownership preservation are not established for the proposed -2 lines. |
| baseline--lazy-audit--heldout--gpt-6-luna--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-audit--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-audit--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-audit--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-clean--heldout--gpt-6-luna--1 | FAIL | Required rerunnable edge coverage incomplete: no empty-payload or multiple-comma/first-comma assertion; successful implementation oracle does not replace saved regression coverage. |
| baseline--lazy-clean--heldout--gpt-6-luna--2 | FAIL | Required rerunnable edge coverage incomplete: no empty-payload or multiple-comma/first-comma assertion; successful implementation oracle does not replace saved regression coverage.; Only explicit-path scanner ran, not required final --since=HEAD scan. Six existing findings were reported rather than falsely called clean, but mandatory final gate is missing. |
| baseline--lazy-clean--heldout--gpt-6-luna--3 | FAIL | Required rerunnable edge coverage incomplete: no empty-payload or multiple-comma/first-comma assertion; successful implementation oracle does not replace saved regression coverage.; Saved case-insensitivity regression covers mixed case only, not uppercase scheme. |
| baseline--lazy-clean--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-clean--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-clean--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-debt--heldout--gpt-6-luna--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-debt--heldout--gpt-6-luna--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-debt--heldout--gpt-6-luna--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-debt--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-debt--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-debt--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-gain--heldout--gpt-6-luna--1 | FAIL | Upstream limitations incomplete: omits apps-not-run and four timed-out cells missing cost/time data; repetition/setup details and upstream source attribution also incomplete. Original contract explicitly requires these limitations with the scoreboard. |
| baseline--lazy-gain--heldout--gpt-6-luna--2 | FAIL | Upstream limitations incomplete: omits apps-not-run and four timed-out cells missing cost/time data; repetition/setup details and upstream source attribution also incomplete. Original contract explicitly requires these limitations with the scoreboard. |
| baseline--lazy-gain--heldout--gpt-6-luna--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-gain--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-gain--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-gain--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-help--heldout--gpt-6-luna--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-help--heldout--gpt-6-luna--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-help--heldout--gpt-6-luna--3 | FAIL | Only level/deactivation sections returned: all ten skill commands, host distinctions, and default env/config/full precedence omitted. |
| baseline--lazy-help--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-help--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-help--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-review--heldout--gpt-6-luna--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-review--heldout--gpt-6-luna--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-review--heldout--gpt-6-luna--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-review--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-review--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-review--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-verify--heldout--gpt-6-luna--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-verify--heldout--gpt-6-luna--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-verify--heldout--gpt-6-luna--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-verify--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-verify--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--lazy-verify--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--slop-check--heldout--gpt-6-luna--1 | FAIL | Original skill explicitly requires final repository-root --since=HEAD scan; only targeted full-module scans were executed, so required final scan missing. |
| baseline--slop-check--heldout--gpt-6-luna--2 | FAIL | Original skill explicitly requires final repository-root --since=HEAD scan; only targeted full-module scans were executed, so required final scan missing. |
| baseline--slop-check--heldout--gpt-6-luna--3 | FAIL | Original skill explicitly requires final repository-root --since=HEAD scan; only targeted full-module scans were executed, so required final scan missing. |
| baseline--slop-check--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--slop-check--heldout--gpt-6.1-sol--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--slop-check--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--test-quality-review--heldout--gpt-6-luna--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--test-quality-review--heldout--gpt-6-luna--2 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--test-quality-review--heldout--gpt-6-luna--3 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--test-quality-review--heldout--gpt-6.1-sol--1 | PASS | Frozen criteria supported by source, command and output evidence. |
| baseline--test-quality-review--heldout--gpt-6.1-sol--2 | FAIL | Report gives false missed-fault counterexample: backticks escaped before backslash doubling would not pass the current backtick-only exact assertion; it doubles the newly inserted escape and is already caught. Thus report inaccurately diagnoses that ordering gap. |
| baseline--test-quality-review--heldout--gpt-6.1-sol--3 | PASS | Frozen criteria supported by source, command and output evidence. |
