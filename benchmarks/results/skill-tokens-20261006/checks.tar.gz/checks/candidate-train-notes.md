# Candidate training quality review

Independent review of frozen candidate instructions, training prompts, captured commands/results, scoped diffs and saved evidence. No baseline runs/grades, heldout cases, proposals, token summaries or previous reviews consulted. CLI completion was not a quality verdict. Any runner record fields incidental to initial inventory were not used for grading or efficiency comparisons.

66 terminal cases graded individually (52 pass, 14 fail); no cases pending. Each JSON entry records pass, reasons and evidence. No outcomes inferred between repetitions.

For each of the ten completed lazy/lazy-clean cases, independently ran the read-only behavior-oracle.mjs train against the final source: 28/28 checks passed. Quality failures there concern missing saved zero regression tests or required final checker execution, not implementation correctness. Saved red/green command evidence and task-owned diffs were inspected separately.

Testing-only failures retained in layz-test are successful bug discovery, not product quality failure. The Sol runs establish real unchanged-passing-test mutation/restoration proof and qualify cap/suffix contract uncertainty. Luna runs lack that feasible proof and blur layer blockers.

Required lazy-verify gate remains blocked without an approved engine; this can be benchmark-quality success, never project verification success. Luna rep1 falsely reports doctor execution absent from the captured commands.

Read-only reviews check actual inventory, source/test oracle flow, correct line counts and preserved boundaries. Positive JSON scanner findings on one explicit requested file establish scanner coverage even without a textual file-count summary. No required final since-HEAD scan was imposed on read-only review or testing-only skills where their frozen contracts do not require it.

All 66 frozen training cases have now been reviewed individually. Of 14 false grades, 2 are terminal execution timeouts/incomplete work and 12 are quality failures among completed runs. No heldout or current/revised candidate inputs were reviewed.

Repetition-3 lazy train both models terminated on timeout with empty diffs and no regression/green verification. They remain failed/incomplete, not inferred model-quality successes. Overnight-clock-gap timing is invalid as performance evidence; no retry was performed.
