# Independent final-recovery quality grading

Complete: **132/132 runs graded; 102 pass, 30 fail; no ungraded or unknown runs.** All 132 records completed with code 0, no timeout, and terminalCompleted true. These are task/contract quality outcomes, not startup-failure model inferences.

Source revision: `b9a34ac7783a1b6c2e1dfff0c08ac744c048fa59`. Two models, medium reasoning, three repetitions, eleven skills, train and heldout variants.

## Evidence boundary and method

Only the assigned `manifest-final-recovery-grading.json`, original `baseline/skills` contracts, frozen `final-recovery/skills` instructions, final-recovery run artifacts and assigned `grading/behavior-oracle.mjs` were used. No other manifests, prior arms, grade/results/selection/optimizer evidence was read. Documents printed by subjects as part of their supplied final-recovery evidence were judged only as that task evidence.

Every run was individually inspected for terminal status, completed commands/results/exits, final response, diff/untracked contents and saved tests/evidence. No run sampling. Unchanged fixture reads were recognized as repeated source, while novel probes, mutations, diffs and saved evidence were inspected. The keyed grade files link actual relative evidence paths; all linked paths exist. No source or run artifact was edited.

Saved full behavioral case coverage was assessed separately from production functionality. An authorized honest failing reproducer is not itself a quality failure. Layz test effectiveness needed feasible unchanged passing-test production mutation or paired red/green evidence, captured bytes/metadata, honest restoration/cleanup and layer applicability. `/tmp` use alone was not an isolation failure, and managed host commands were not treated as automatic child-tree leaks.

Read-only test-quality review can pass with reasoned whole-test counterexamples or a justified clean review; mutation and bug quotas are not required. Missing approved lazy-verify engines can pass benchmark quality as honest blocked gates after contract/profile/policy inspection, never as release readiness. Unrun doctor/verify inspected semantics were kept distinct from observed exits. Only the selected profile mode was required.

Original slop final repository-root `--since=HEAD` requirement was applied even to read-only reviews. Focused scan/explain alone does not meet that gate. Scalar single-file JSON findings are valid. Retained no-any findings were not treated as clean.

## Quality totals by model and variant

| Model | Variant | Pass | Fail | Total |
|---|---|---:|---:|---:|
| gpt-6.1-sol | train | 32 | 1 | 33 |
| gpt-6.1-sol | heldout | 32 | 1 | 33 |
| gpt-6-luna | train | 20 | 13 | 33 |
| gpt-6-luna | heldout | 18 | 15 | 33 |

## Quality totals by skill/model/variant

| Skill | Model | Variant | Pass | Fail | Total |
|---|---|---|---:|---:|---:|
| layz-test | gpt-6.1-sol | train | 2 | 1 | 3 |
| layz-test | gpt-6.1-sol | heldout | 2 | 1 | 3 |
| layz-test | gpt-6-luna | train | 0 | 3 | 3 |
| layz-test | gpt-6-luna | heldout | 0 | 3 | 3 |
| lazy | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy | gpt-6-luna | train | 0 | 3 | 3 |
| lazy | gpt-6-luna | heldout | 0 | 3 | 3 |
| lazy-audit | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy-audit | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy-audit | gpt-6-luna | train | 2 | 1 | 3 |
| lazy-audit | gpt-6-luna | heldout | 1 | 2 | 3 |
| lazy-clean | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy-clean | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy-clean | gpt-6-luna | train | 0 | 3 | 3 |
| lazy-clean | gpt-6-luna | heldout | 0 | 3 | 3 |
| lazy-debt | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy-debt | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy-debt | gpt-6-luna | train | 3 | 0 | 3 |
| lazy-debt | gpt-6-luna | heldout | 3 | 0 | 3 |
| lazy-gain | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy-gain | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy-gain | gpt-6-luna | train | 3 | 0 | 3 |
| lazy-gain | gpt-6-luna | heldout | 3 | 0 | 3 |
| lazy-help | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy-help | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy-help | gpt-6-luna | train | 3 | 0 | 3 |
| lazy-help | gpt-6-luna | heldout | 3 | 0 | 3 |
| lazy-review | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy-review | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy-review | gpt-6-luna | train | 3 | 0 | 3 |
| lazy-review | gpt-6-luna | heldout | 2 | 1 | 3 |
| lazy-verify | gpt-6.1-sol | train | 3 | 0 | 3 |
| lazy-verify | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| lazy-verify | gpt-6-luna | train | 3 | 0 | 3 |
| lazy-verify | gpt-6-luna | heldout | 3 | 0 | 3 |
| slop-check | gpt-6.1-sol | train | 3 | 0 | 3 |
| slop-check | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| slop-check | gpt-6-luna | train | 0 | 3 | 3 |
| slop-check | gpt-6-luna | heldout | 0 | 3 | 3 |
| test-quality-review | gpt-6.1-sol | train | 3 | 0 | 3 |
| test-quality-review | gpt-6.1-sol | heldout | 3 | 0 | 3 |
| test-quality-review | gpt-6-luna | train | 3 | 0 | 3 |
| test-quality-review | gpt-6-luna | heldout | 3 | 0 | 3 |

## Actual executed functional oracles

**24/24 required production-fix implementations executed: 12 train runs × 28 checks and 12 heldout runs × 27 checks = 660 actual checks, all passing.** These are lazy/lazy-clean implementations only; the 12 test-only layz baseline artifacts were not added to this count.

Exact command form: `node grading/behavior-oracle.mjs <train|heldout> runs/<runid>/workspace/packages/isomorphic/stringUtils.ts`. Each command actually ran against its delivered implementation; captured JSON and stderr were saved only in grader scratch. All executions returned code 0. Passing functionality does not override missing saved regression coverage or contract gates.

| Model | Variant | Executions | Checks passed | Failed |
|---|---|---:|---:|---:|
| gpt-6.1-sol | train | 6 | 168 | 0 |
| gpt-6.1-sol | heldout | 6 | 162 | 0 |
| gpt-6-luna | train | 6 | 168 | 0 |
| gpt-6-luna | heldout | 6 | 162 | 0 |

### Retained actual oracle logs

- [final-recovery--lazy--heldout--gpt-6-luna--1.oracle.json](recovery-grader-scratch/final-recovery--lazy--heldout--gpt-6-luna--1.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--heldout--gpt-6-luna--1.oracle.stderr`.
- [final-recovery--lazy--heldout--gpt-6-luna--2.oracle.json](recovery-grader-scratch/final-recovery--lazy--heldout--gpt-6-luna--2.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--heldout--gpt-6-luna--2.oracle.stderr`.
- [final-recovery--lazy--heldout--gpt-6-luna--3.oracle.json](recovery-grader-scratch/final-recovery--lazy--heldout--gpt-6-luna--3.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--heldout--gpt-6-luna--3.oracle.stderr`.
- [final-recovery--lazy--heldout--gpt-6.1-sol--1.oracle.json](recovery-grader-scratch/final-recovery--lazy--heldout--gpt-6.1-sol--1.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--heldout--gpt-6.1-sol--1.oracle.stderr`.
- [final-recovery--lazy--heldout--gpt-6.1-sol--2.oracle.json](recovery-grader-scratch/final-recovery--lazy--heldout--gpt-6.1-sol--2.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--heldout--gpt-6.1-sol--2.oracle.stderr`.
- [final-recovery--lazy--heldout--gpt-6.1-sol--3.oracle.json](recovery-grader-scratch/final-recovery--lazy--heldout--gpt-6.1-sol--3.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--heldout--gpt-6.1-sol--3.oracle.stderr`.
- [final-recovery--lazy--train--gpt-6-luna--1.oracle.json](recovery-grader-scratch/final-recovery--lazy--train--gpt-6-luna--1.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--train--gpt-6-luna--1.oracle.stderr`.
- [final-recovery--lazy--train--gpt-6-luna--2.oracle.json](recovery-grader-scratch/final-recovery--lazy--train--gpt-6-luna--2.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--train--gpt-6-luna--2.oracle.stderr`.
- [final-recovery--lazy--train--gpt-6-luna--3.oracle.json](recovery-grader-scratch/final-recovery--lazy--train--gpt-6-luna--3.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--train--gpt-6-luna--3.oracle.stderr`.
- [final-recovery--lazy--train--gpt-6.1-sol--1.oracle.json](recovery-grader-scratch/final-recovery--lazy--train--gpt-6.1-sol--1.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--train--gpt-6.1-sol--1.oracle.stderr`.
- [final-recovery--lazy--train--gpt-6.1-sol--2.oracle.json](recovery-grader-scratch/final-recovery--lazy--train--gpt-6.1-sol--2.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--train--gpt-6.1-sol--2.oracle.stderr`.
- [final-recovery--lazy--train--gpt-6.1-sol--3.oracle.json](recovery-grader-scratch/final-recovery--lazy--train--gpt-6.1-sol--3.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy--train--gpt-6.1-sol--3.oracle.stderr`.
- [final-recovery--lazy-clean--heldout--gpt-6-luna--1.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--heldout--gpt-6-luna--1.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--heldout--gpt-6-luna--1.oracle.stderr`.
- [final-recovery--lazy-clean--heldout--gpt-6-luna--2.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--heldout--gpt-6-luna--2.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--heldout--gpt-6-luna--2.oracle.stderr`.
- [final-recovery--lazy-clean--heldout--gpt-6-luna--3.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--heldout--gpt-6-luna--3.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--heldout--gpt-6-luna--3.oracle.stderr`.
- [final-recovery--lazy-clean--heldout--gpt-6.1-sol--1.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--heldout--gpt-6.1-sol--1.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--heldout--gpt-6.1-sol--1.oracle.stderr`.
- [final-recovery--lazy-clean--heldout--gpt-6.1-sol--2.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--heldout--gpt-6.1-sol--2.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--heldout--gpt-6.1-sol--2.oracle.stderr`.
- [final-recovery--lazy-clean--heldout--gpt-6.1-sol--3.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--heldout--gpt-6.1-sol--3.oracle.json): 27 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--heldout--gpt-6.1-sol--3.oracle.stderr`.
- [final-recovery--lazy-clean--train--gpt-6-luna--1.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--train--gpt-6-luna--1.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--train--gpt-6-luna--1.oracle.stderr`.
- [final-recovery--lazy-clean--train--gpt-6-luna--2.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--train--gpt-6-luna--2.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--train--gpt-6-luna--2.oracle.stderr`.
- [final-recovery--lazy-clean--train--gpt-6-luna--3.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--train--gpt-6-luna--3.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--train--gpt-6-luna--3.oracle.stderr`.
- [final-recovery--lazy-clean--train--gpt-6.1-sol--1.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--train--gpt-6.1-sol--1.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--train--gpt-6.1-sol--1.oracle.stderr`.
- [final-recovery--lazy-clean--train--gpt-6.1-sol--2.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--train--gpt-6.1-sol--2.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--train--gpt-6.1-sol--2.oracle.stderr`.
- [final-recovery--lazy-clean--train--gpt-6.1-sol--3.oracle.json](recovery-grader-scratch/final-recovery--lazy-clean--train--gpt-6.1-sol--3.oracle.json): 28 passed, 0 failed; stderr captured in adjacent `final-recovery--lazy-clean--train--gpt-6.1-sol--3.oracle.stderr`.

## Original slop gate evidence

All six Sol slop reviews pass quality: 3/3 train and 3/3 heldout. All six Luna slop reviews fail quality: 0/3 train and 0/3 heldout. Sol actually ran the final root since-HEAD scan, which checked zero unchanged files and was explicitly reported as no added coverage; focused scans retained 2 train or 6 heldout findings. Luna actually ran focused scans and explanations but omitted the final root since-HEAD scan. No grading decision was based on proposed final scope changes.

| Run | Actual root since-HEAD command | Result |
|---|---|---|
| [final-recovery--slop-check--train--gpt-6.1-sol--1](runs/final-recovery--slop-check--train--gpt-6.1-sol--1/stdout.jsonl) | `node skill-files/slop-check/scripts/check.mjs --since=HEAD packages/isomorphic/timeoutRunner.ts` (equivalent recorded argument order) | Observed exit 0; 0 files; no added coverage |
| [final-recovery--slop-check--train--gpt-6.1-sol--2](runs/final-recovery--slop-check--train--gpt-6.1-sol--2/stdout.jsonl) | `node skill-files/slop-check/scripts/check.mjs --since=HEAD packages/isomorphic/timeoutRunner.ts` (equivalent recorded argument order) | Observed exit 0; 0 files; no added coverage |
| [final-recovery--slop-check--train--gpt-6.1-sol--3](runs/final-recovery--slop-check--train--gpt-6.1-sol--3/stdout.jsonl) | `node skill-files/slop-check/scripts/check.mjs --since=HEAD packages/isomorphic/timeoutRunner.ts` (equivalent recorded argument order) | Observed exit 0; 0 files; no added coverage |
| [final-recovery--slop-check--heldout--gpt-6.1-sol--1](runs/final-recovery--slop-check--heldout--gpt-6.1-sol--1/stdout.jsonl) | `node skill-files/slop-check/scripts/check.mjs --since=HEAD packages/isomorphic/stringUtils.ts` (equivalent recorded argument order) | Observed exit 0; 0 files; no added coverage |
| [final-recovery--slop-check--heldout--gpt-6.1-sol--2](runs/final-recovery--slop-check--heldout--gpt-6.1-sol--2/stdout.jsonl) | `node skill-files/slop-check/scripts/check.mjs --since=HEAD packages/isomorphic/stringUtils.ts` (equivalent recorded argument order) | Observed exit 0; 0 files; no added coverage |
| [final-recovery--slop-check--heldout--gpt-6.1-sol--3](runs/final-recovery--slop-check--heldout--gpt-6.1-sol--3/stdout.jsonl) | `node skill-files/slop-check/scripts/check.mjs --since=HEAD packages/isomorphic/stringUtils.ts` (equivalent recorded argument order) | Observed exit 0; 0 files; no added coverage |
| [final-recovery--slop-check--train--gpt-6-luna--1](runs/final-recovery--slop-check--train--gpt-6-luna--1/stdout.jsonl) | `Omitted; focused scan/explain only` | Original final gate unmet |
| [final-recovery--slop-check--train--gpt-6-luna--2](runs/final-recovery--slop-check--train--gpt-6-luna--2/stdout.jsonl) | `Omitted; focused scan/explain only` | Original final gate unmet |
| [final-recovery--slop-check--train--gpt-6-luna--3](runs/final-recovery--slop-check--train--gpt-6-luna--3/stdout.jsonl) | `Omitted; focused scan/explain only` | Original final gate unmet |
| [final-recovery--slop-check--heldout--gpt-6-luna--1](runs/final-recovery--slop-check--heldout--gpt-6-luna--1/stdout.jsonl) | `Omitted; focused scan/explain only` | Original final gate unmet |
| [final-recovery--slop-check--heldout--gpt-6-luna--2](runs/final-recovery--slop-check--heldout--gpt-6-luna--2/stdout.jsonl) | `Omitted; focused scan/explain only` | Original final gate unmet |
| [final-recovery--slop-check--heldout--gpt-6-luna--3](runs/final-recovery--slop-check--heldout--gpt-6-luna--3/stdout.jsonl) | `Omitted; focused scan/explain only` | Original final gate unmet |

## Failed-quality runs

Reasons below are summarized from each individually reviewed keyed grade, not inferred from token usage or model labels. Correct implementations may fail saved-coverage or workflow gates.

| Run | Reason |
|---|---|
| [final-recovery--layz-test--heldout--gpt-6-luna--1](runs/final-recovery--layz-test--heldout--gpt-6-luna--1/stdout.jsonl) | Baseline 5/5 and final11/12 honestly reported; retained interpolation reproducer without product edits is valid discovery, not a failing grade by itself.; No feasible unchanged passing-test production mutation or paired intended red/green proof; no captured-byte/metadata verification.; Available slop scan after JavaScript test edits never ran; static/tool applicability not properly checked before broad not-run declaration. |
| [final-recovery--layz-test--heldout--gpt-6-luna--2](runs/final-recovery--layz-test--heldout--gpt-6-luna--2/stdout.jsonl) | Honest corrected test-oracle mistakes, final 11 passed and one retained interpolation red on unchanged source; direct runtime reproduction confirms interpolation. No feasible unchanged passing-test production mutation or paired intended red/green effectiveness proof, captured-byte/mode restoration evidence, or available final slop scan. Static/build described as outside helper scope rather than checking applicability/blocker; broad security finding is not independently traced to an affected backtick caller. |
| [final-recovery--layz-test--heldout--gpt-6-luna--3](runs/final-recovery--layz-test--heldout--gpt-6-luna--3/stdout.jsonl) | Baseline5/5 then7 pass/one retained CR normalization red on unchanged product is honestly reported, but no feasible unchanged passing-test production mutation or paired effectiveness proof/captured restoration evidence and no available final slop scan after JS edits. Report labels CR roundtrip loss a confirmed defect without qualifying the absent newline-preservation caller/contract; it also omits quoted backtick interpolation coverage. |
| [final-recovery--layz-test--heldout--gpt-6.1-sol--2](runs/final-recovery--layz-test--heldout--gpt-6.1-sol--2/stdout.jsonl) | Saved extensive escaping/control/Unicode/generated/large-input coverage and honest inferred interpolation red: 19 passed, one retained failed. Three unchanged-test production mutations have actual intended assertion failures, captured bytes/modes and restoration/cleanup proof. Quality fails because the available slop checker was neither inspected nor run after JavaScript edits; report incorrectly says no installed checker and lists slop as blocked. |
| [final-recovery--layz-test--train--gpt-6-luna--1](runs/final-recovery--layz-test--train--gpt-6-luna--1/stdout.jsonl) | Honest initial 5/5 and final 8/9 run preserves confirmed zero-cap reproducer without production edits, but no unchanged passing-test production mutation or paired intended red/green proof despite feasibility.; No captured source-byte and behavior-relevant metadata verification; no installed slop scan after JS test edits.; Saved cases omit nonempty custom suffix fitting/exceeding cap and astral suffix behavior; no full boundary case coverage. |
| [final-recovery--layz-test--train--gpt-6-luna--2](runs/final-recovery--layz-test--train--gpt-6-luna--2/stdout.jsonl) | Honest unchanged-source discovery: baseline 5/5; expanded saved suite 10 passed and one genuine zero-cap red reproducer retained. The retained failure is not itself a quality failure. Required feasible unchanged passing-test production mutation or paired intended red/green proof was not performed, and no captured-byte/mode restoration evidence exists. Available final slop scan after JavaScript test edits was omitted. Saved suffix tests omit oversized and supplementary-character suffix boundaries despite the requested boundary coverage. |
| [final-recovery--layz-test--train--gpt-6-luna--3](runs/final-recovery--layz-test--train--gpt-6-luna--3/stdout.jsonl) | Actual baseline5/5 then9 pass/3 red with production unchanged and final one-file slop clean, but saved oracles/report misclassify code-point-fitting input as a bug: trimStringWithEllipsis(emoji+x,2) correctly preserves fitting input, yet test demands emoji+ellipsis. Zero-cap and oversized suffix expectations themselves exceed the claimed maximum-output cap. Qualification as an assumption does not make inconsistent oracles confirmed bugs. Required feasible unchanged passing-test production mutation/paired proof and captured restoration evidence also absent. |
| [final-recovery--layz-test--train--gpt-6.1-sol--1](runs/final-recovery--layz-test--train--gpt-6.1-sol--1/stdout.jsonl) | Strong scoped coverage and honest retained 17-pass/1-fail zero-cap defect; three feasible unchanged-test production mutations fail intended assertions, control/restored passes, captured hashes/modes verified and cleanup recorded.; Required available slop scan after JS test edits never ran; report incorrectly claims no slop checker despite workspace/skill-files/slop-check/scripts/check.mjs being present. |
| [final-recovery--lazy--heldout--gpt-6-luna--1](runs/final-recovery--lazy--heldout--gpt-6-luna--1/stdout.jsonl) | Correct one-line production fix with oracle27/27; meaningful unchanged mixedcase baseline assertion then8/8green; sinceHEAD clean2files.; Saved tests omit uppercase scheme with payload, first-comma multiple-comma case and empty payload; complete requested regression coverage not established. |
| [final-recovery--lazy--heldout--gpt-6-luna--2](runs/final-recovery--lazy--heldout--gpt-6-luna--2/stdout.jsonl) | Correct scoped implementation; independent functional oracle 27/27 and actual mixed-case original assertion failure then final 7/7 with two-file root scanner clean. Saved rerunnable cases omit uppercase payload recognition, first-comma selection with multiple commas, and empty payload; therefore requested full behavioral case coverage is incomplete. |
| [final-recovery--lazy--heldout--gpt-6-luna--3](runs/final-recovery--lazy--heldout--gpt-6-luna--3/stdout.jsonl) | Correct functional implementation (oracle27/27), actual uppercase inline pre-fixred and final7/7, but saved tests omit uppercase payload, firstcomma multiple payload commas and empty payload. Wrong lazy/scripts checker path failed; available slop-check/scripts checker was not run and final report falsely says referenced checker absent. |
| [final-recovery--lazy--train--gpt-6-luna--1](runs/final-recovery--lazy--train--gpt-6-luna--1/stdout.jsonl) | Independent train oracle28/28 and actual unchanged regression2fail then8/8green, final sinceHEAD scanner clean2files.; Saved regression cases omit explicit zero cap, empty input, suffix equal-cap, and ASCII custom-suffix boundaries; required full behavioral edge coverage not satisfied despite correct implementation. |
| [final-recovery--lazy--train--gpt-6-luna--2](runs/final-recovery--lazy--train--gpt-6-luna--2/stdout.jsonl) | Implementation is functionally correct (independent oracle 28/28), with actual two original assertion failures then 9/9 and final two-file scanner clean. Saved coverage omits explicitly required zero-cap and empty-input checks and equal-suffix boundary; functional correctness does not substitute for requested rerunnable case coverage. |
| [final-recovery--lazy--train--gpt-6-luna--3](runs/final-recovery--lazy--train--gpt-6-luna--3/stdout.jsonl) | Correct functional implementation (oracle28/28), actual2red then9/9 and root2filechecker clean, but requested saved zero/empty and equal-suffix cases omitted. |
| [final-recovery--lazy-audit--heldout--gpt-6-luna--1](runs/final-recovery--lazy-audit--heldout--gpt-6-luna--1/stdout.jsonl) | Whole five-file scoped source/test inventory read; valid union-narrowed cast recommendation, tally and read-only artifact.; Original required pinned/installed language-version check omitted: no runtime or package/snapshot version read and no unknown-version disclosure. |
| [final-recovery--lazy-audit--heldout--gpt-6-luna--3](runs/final-recovery--lazy-audit--heldout--gpt-6-luna--3/stdout.jsonl) | Proposes removing the destructured array copy in pollAgainstDeadline on the false premise that it is a rest parameter. It is a single array argument; removing its copy makes pop/shift mutate the caller-owned intervals, violating behavior preservation. |
| [final-recovery--lazy-audit--train--gpt-6-luna--1](runs/final-recovery--lazy-audit--train--gpt-6-luna--1/stdout.jsonl) | All five scoped source/test files actually read; final correct five-file inventory, safe casts/non-null simplification after union guard, no edits and tally.; Original required pinned/installed language version check not performed: no package/snapshot version or runtime command, nor unknown-version disclosure. |
| [final-recovery--lazy-clean--heldout--gpt-6-luna--1](runs/final-recovery--lazy-clean--heldout--gpt-6-luna--1/stdout.jsonl) | Correct narrow implementation oracle27/27; actual unchanged mixedcase intended assertion fails then7/7green, finalsinceHEAD clean2files.; Saved regression coverage lacks uppercase with payload, multiple-comma/firstcomma and empty payload cases despite original full coverage requirement. |
| [final-recovery--lazy-clean--heldout--gpt-6-luna--2](runs/final-recovery--lazy-clean--heldout--gpt-6-luna--2/stdout.jsonl) | Functionally correct (independent oracle 27/27), actual original uppercase assertion failure then 7/7 with final two-file scanner clean. Saved tests omit first-comma selection with multiple commas and empty payload; requested full behavioral coverage incomplete. |
| [final-recovery--lazy-clean--heldout--gpt-6-luna--3](runs/final-recovery--lazy-clean--heldout--gpt-6-luna--3/stdout.jsonl) | Functional oracle passes 27/27 and actual mixed-case red then 7 green with root scan, but saved tests omit uppercase payload, multiple-comma first-comma behavior and empty payload required by full case scope. |
| [final-recovery--lazy-clean--train--gpt-6-luna--1](runs/final-recovery--lazy-clean--train--gpt-6-luna--1/stdout.jsonl) | Oracle28/28 with narrow correct production fix; actual unchanged2red assertions then9/9green; final sinceHEAD scanner clean2files.; Saved regressions lack explicit zero/empty and equal-cap suffix boundaries required for full behavioral coverage. |
| [final-recovery--lazy-clean--train--gpt-6-luna--2](runs/final-recovery--lazy-clean--train--gpt-6-luna--2/stdout.jsonl) | Functionally correct (independent oracle 28/28), actual original oversized suffix assertion failure then 8/8 with final two-file scanner clean. Saved tests omit zero/empty, fitting astral suffix and equal-suffix boundaries; requested full behavioral coverage incomplete. |
| [final-recovery--lazy-clean--train--gpt-6-luna--3](runs/final-recovery--lazy-clean--train--gpt-6-luna--3/stdout.jsonl) | Functional oracle passes 28/28, but saved tests omit zero/empty/equal-suffix and wrapper edge cases. Initial fitting-input suffix expectation was wrong, persisted after production fix then changed, yet final calls both initial failures regressions; only oversized-suffix failure was genuine. |
| [final-recovery--lazy-review--heldout--gpt-6-luna--2](runs/final-recovery--lazy-review--heldout--gpt-6-luna--2/stdout.jsonl) | Correct seeded redundant else/nonnegative check/return finding, no edits and otherwise suitable scoped report. Original review contract requires reading language version facts; only package head80 read (TS pin at line159 omitted), no snapshot/runtime version read or unknown disclosure. Required compatibility/version check is absent. |
| [final-recovery--slop-check--heldout--gpt-6-luna--1](runs/final-recovery--slop-check--heldout--gpt-6-luna--1/stdout.jsonl) | Actual focused module scanner6noany findings and correct escape-key/format/cache invariants,5/5Node harness, read-only and no false clean.; Mandatory final repository-root sinceHEAD scanner omitted; pinned/installed language version not read, unicodeSets compatibility cast retained without compiler/lib applicability check. |
| [final-recovery--slop-check--heldout--gpt-6-luna--2](runs/final-recovery--slop-check--heldout--gpt-6-luna--2/stdout.jsonl) | Actual one-file scanner flags all six no-any findings; reads whole module/checklist, triages unknown boundary inputs, HTML matched-key invariant and conditional unicodeSets compatibility without blindly rewriting. Mandatory final repository-root --since=HEAD scan omitted. Focused scan and explain do not satisfy original completion contract. Findings retained honestly, not reported clean; compatibility assertion need remains unconfirmed. |
| [final-recovery--slop-check--heldout--gpt-6-luna--3](runs/final-recovery--slop-check--heldout--gpt-6-luna--3/stdout.jsonl) | Actual focused scan reports six retained no-any findings with honest invariant and compatibility triage, but required final repository-root --since=HEAD scan omitted. |
| [final-recovery--slop-check--train--gpt-6-luna--1](runs/final-recovery--slop-check--train--gpt-6-luna--1/stdout.jsonl) | Actual module scan2noany findings with correct typed union invariant and supplied test context; no edits/false clean.; Required final repository-root sinceHEAD scan omitted: focused scan and explain only, including failed placeholder RULE explanation; full manual lifecycle/interval checks not reported. |
| [final-recovery--slop-check--train--gpt-6-luna--2](runs/final-recovery--slop-check--train--gpt-6-luna--2/stdout.jsonl) | Actual focused one-file scan flags two no-any findings; manual typed-union, intervals, deadline/timer/callback lifecycle triage is valid and read-only. Mandatory final repository-root --since=HEAD scan was omitted; corrected explain-rule lookup and focused scan do not satisfy original completion contract. Retained findings are honestly reported, not clean. |
| [final-recovery--slop-check--train--gpt-6-luna--3](runs/final-recovery--slop-check--train--gpt-6-luna--3/stdout.jsonl) | Focused scanner honestly reports two no-any findings and correct union-invariant triage, but required final repository-root --since=HEAD scan was omitted; focused scan and explanation are not that gate. |

## Completion validation

Exact manifest Cartesian product equals both grade-file key sets combined: 132 unique entries, 66 train and 66 heldout. Every entry has a boolean pass, nonempty reasons and nonempty existing evidence references. All 24 required actual oracle JSON/stderr pairs remain saved. No source/run artifacts were changed; no checks were invented.
